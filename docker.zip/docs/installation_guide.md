# 개발 환경 설치 가이드
## IDE, Postman, PostgreSQL 상세 설치 방법

---

## 📌 Part 1: IDE 설치 (VSCode 또는 PyCharm)

### Option A: Visual Studio Code (무료, 권장)

#### Windows 설치
1. **다운로드**
   - https://code.visualstudio.com 접속
   - "Download for Windows" 클릭
   - VSCodeUserSetup-x64-1.84.exe 다운로드

2. **설치 과정**
   - 다운로드한 파일 실행
   - "동의함" 선택 → 다음
   - 설치 경로 확인 → 다음
   - **중요 옵션 체크**:
     - ✅ "PATH에 추가" 
     - ✅ "Code로 열기 작업을 Windows 탐색기 파일 컨텍스트 메뉴에 추가"
     - ✅ "Code로 열기 작업을 Windows 탐색기 디렉터리 컨텍스트 메뉴에 추가"
   - 설치 → 완료

3. **Python 확장 설치**
   - VSCode 실행
   - 왼쪽 사이드바에서 Extensions 아이콘 클릭 (또는 Ctrl+Shift+X)
   - "Python" 검색
   - Microsoft 제공 Python extension 설치
   - "Python Extension Pack" 추가 설치 (선택)

#### Mac 설치
```bash
# Homebrew가 있는 경우
brew install --cask visual-studio-code

# 또는 웹사이트에서 다운로드
# https://code.visualstudio.com/Download
# "Download for Mac" 클릭
# VSCode.zip 다운로드 후 Applications 폴더로 이동
```

#### Linux (Ubuntu/Debian) 설치
```bash
# 방법 1: snap 사용
sudo snap install code --classic

# 방법 2: apt 사용
wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg
sudo install -o root -g root -m 644 packages.microsoft.gpg /etc/apt/trusted.gpg.d/
sudo sh -c 'echo "deb [arch=amd64,arm64,armhf signed-by=/etc/apt/trusted.gpg.d/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main" > /etc/apt/sources.list.d/vscode.list'

sudo apt update
sudo apt install code
```

### Option B: PyCharm Community (무료)

#### Windows 설치
1. **다운로드**
   - https://www.jetbrains.com/pycharm/download/ 접속
   - Community Edition "Download" 클릭
   - pycharm-community-2023.3.exe 다운로드

2. **설치 과정**
   - 설치 파일 실행
   - Next → 설치 경로 선택 → Next
   - **설치 옵션**:
     - ✅ "64-bit launcher" 
     - ✅ "Add launchers dir to the PATH"
     - ✅ ".py" (Python 파일 연결)
   - Install → 완료

3. **초기 설정**
   - PyCharm 실행
   - "Do not import settings" → OK
   - UI 테마 선택 (Darcula 또는 Light)
   - Python 인터프리터 설정

#### Mac 설치
```bash
# Homebrew 사용
brew install --cask pycharm-ce

# 또는 웹사이트에서 다운로드
# DMG 파일 다운로드 후 Applications로 드래그
```

---

## 📌 Part 2: Postman 설치

### Windows 설치
1. **다운로드**
   - https://www.postman.com/downloads/ 접속
   - "Download for Windows 64-bit" 클릭
   - Postman-win64-Setup.exe 다운로드

2. **설치 및 설정**
   - 설치 파일 실행 (자동 설치됨)
   - Postman 실행
   - **계정 설정 (선택)**:
     - "Skip and go to the app" 클릭 (계정 없이 사용)
     - 또는 "Sign Up for Free" (클라우드 동기화 원할 경우)

3. **초기 화면**
   - "Create New" → "HTTP Request" 선택
   - 또는 Workspace 생성 후 사용

### Mac 설치
```bash
# Homebrew 사용
brew install --cask postman

# 또는 웹사이트에서 다운로드
# https://www.postman.com/downloads/
# Mac (Apple Chip 또는 Intel) 선택
```

### Linux 설치
```bash
# Snap 사용 (권장)
sudo snap install postman

# 또는 수동 설치
wget https://dl.pstmn.io/download/latest/linux64 -O postman.tar.gz
tar -xzf postman.tar.gz
sudo mv Postman /opt
sudo ln -s /opt/Postman/Postman /usr/local/bin/postman
```

### Postman 기본 사용법 확인
1. **새 Request 생성**
   - Collections → + → Add request
   - 또는 상단 "+" 탭 클릭

2. **테스트 요청**
   ```
   Method: GET
   URL: https://jsonplaceholder.typicode.com/users
   ```
   - Send 클릭
   - 하단에 JSON 응답 확인되면 정상

---

## 📌 Part 3: PostgreSQL & pgAdmin 설치

### Windows 설치 (가장 쉬운 방법)

1. **다운로드**
   - https://www.postgresql.org/download/windows/ 접속
   - "Download the installer" 클릭
   - PostgreSQL 15 또는 16 선택
   - Windows x86-64 다운로드

2. **설치 과정**
   - postgresql-16-windows-x64.exe 실행
   - Next → 설치 경로 (기본값 권장) → Next
   
3. **구성 요소 선택**
   - ✅ PostgreSQL Server (필수)
   - ✅ pgAdmin 4 (필수)
   - ✅ Stack Builder (선택)
   - ✅ Command Line Tools (필수)

4. **데이터 디렉토리**
   - 기본값 사용: `C:\Program Files\PostgreSQL\16\data`
   - Next

5. **비밀번호 설정** ⭐ 중요
   - superuser (postgres) 비밀번호 입력
   - **비밀번호 꼭 기억하세요!** (예: postgres123)
   - 비밀번호 확인

6. **포트 설정**
   - 기본값: 5432 (변경하지 않음)
   - Next

7. **Locale 설정**
   - Default locale 또는 Korean, Republic of Korea
   - Next → Next → Install

8. **설치 완료**
   - Stack Builder 실행 여부 → 체크 해제 → Finish

### Mac 설치

#### 방법 1: Homebrew (권장)
```bash
# PostgreSQL 설치
brew install postgresql@16

# 서비스 시작
brew services start postgresql@16

# pgAdmin 별도 설치
brew install --cask pgadmin4
```

#### 방법 2: 공식 앱
1. https://postgresapp.com/ 에서 다운로드
2. Postgres.app을 Applications로 이동
3. 앱 실행 → Initialize 클릭

### Linux (Ubuntu/Debian) 설치
```bash
# PostgreSQL 설치
sudo apt update
sudo apt install postgresql postgresql-contrib

# pgAdmin 설치
curl -fsS https://www.pgadmin.org/static/packages_pgadmin_org.pub | sudo gpg --dearmor -o /usr/share/keyrings/packages-pgadmin-org.gpg

sudo sh -c 'echo "deb [signed-by=/usr/share/keyrings/packages-pgadmin-org.gpg] https://ftp.postgresql.org/pub/pgadmin/pgadmin4/apt/$(lsb_release -cs) pgadmin4 main" > /etc/apt/sources.list.d/pgadmin4.list'

sudo apt update
sudo apt install pgadmin4-desktop

# PostgreSQL 서비스 시작
sudo systemctl start postgresql
sudo systemctl enable postgresql

# postgres 사용자 비밀번호 설정
sudo -u postgres psql
ALTER USER postgres PASSWORD 'your_password';
\q
```

### pgAdmin 초기 설정

1. **pgAdmin 실행**
   - Windows: 시작 메뉴 → pgAdmin 4
   - Mac: Applications → pgAdmin 4
   - Linux: 터미널에서 `pgadmin4`

2. **마스터 비밀번호 설정**
   - 첫 실행시 마스터 비밀번호 설정
   - pgAdmin 자체 보안용 (PostgreSQL 비밀번호와 다름)

3. **서버 등록**
   - 왼쪽 패널: Servers → 우클릭 → Register → Server
   - **General 탭**:
     - Name: LocalDB (원하는 이름)
   - **Connection 탭**:
     - Host: localhost
     - Port: 5432
     - Username: postgres
     - Password: (설치시 설정한 비밀번호)
     - ✅ Save password
   - Save 클릭

4. **연결 확인**
   - Servers → LocalDB 더블클릭
   - Databases 목록이 보이면 성공

---

## 📌 설치 확인 체크리스트

### 1. Python 확인
```bash
python --version
# 또는
python3 --version

# 출력: Python 3.9.x 이상이어야 함
```

### 2. pip 확인
```bash
pip --version
# 또는
pip3 --version

# 출력: pip 21.x.x from ...
```

### 3. PostgreSQL 확인
```bash
psql --version

# 출력: psql (PostgreSQL) 15.x 또는 16.x
```

### 4. VSCode/PyCharm에서 Python 실행
```python
# test.py 파일 생성
print("Hello, ML Class!")

# 실행:
# VSCode: 우상단 ▶️ 버튼 또는 Ctrl+F5
# PyCharm: 우클릭 → Run 또는 Shift+F10
```

### 5. Postman 테스트
1. Postman 열기
2. 새 Request
3. GET https://httpbin.org/get
4. Send → 응답 확인

### 6. pgAdmin 테스트
1. pgAdmin 열기
2. 서버 연결
3. Query Tool 열기
4. 실행:
```sql
SELECT version();
```
5. PostgreSQL 버전 정보 출력되면 성공

---

## 🔧 자주 발생하는 문제 해결

### 문제 1: "python" 명령어가 없다고 나옴
```bash
# Windows: Python 설치시 "Add to PATH" 체크 안함
# 해결: Python 재설치 또는 수동 PATH 추가

# Mac/Linux: python3 사용
alias python=python3
alias pip=pip3
```

### 문제 2: PostgreSQL 비밀번호 잊음
```bash
# Windows
1. services.msc 실행
2. postgresql-x64-16 서비스 중지
3. pg_hba.conf 파일 편집 (C:\Program Files\PostgreSQL\16\data)
4. "local all all trust"로 변경
5. 서비스 재시작
6. psql -U postgres 로 접속
7. ALTER USER postgres PASSWORD 'new_password';

# Mac/Linux
sudo -u postgres psql
ALTER USER postgres PASSWORD 'new_password';
```

### 문제 3: pgAdmin이 브라우저에서 안 열림
- 방화벽/백신 프로그램 확인
- 다른 브라우저 시도
- 직접 URL 입력: http://127.0.0.1:5050

### 문제 4: VSCode에서 Python 인터프리터 못 찾음
1. Ctrl+Shift+P (명령 팔레트)
2. "Python: Select Interpreter" 입력
3. Python 경로 선택

### 문제 5: Postman 느림
- Settings → General → Request timeout 조정
- SSL certificate verification 끄기 (개발용)

---

## ✅ 모든 설치 완료 후 최종 테스트

1. **터미널/명령 프롬프트**
```bash
# 프로젝트 폴더 생성
mkdir ml_class_test
cd ml_class_test

# 가상환경 생성
python -m venv venv

# 활성화
# Windows: venv\Scripts\activate
# Mac/Linux: source venv/bin/activate

# 패키지 설치
pip install fastapi uvicorn psycopg2-binary
```

2. **VSCode/PyCharm에서 프로젝트 열기**
   - File → Open Folder → ml_class_test 선택

3. **test_api.py 생성**
```python
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"Hello": "ML Class"}
```

4. **실행**
```bash
uvicorn test_api:app --reload
```

5. **Postman에서 테스트**
   - GET http://localhost:8000
   - 응답: {"Hello": "ML Class"}

6. **pgAdmin에서 DB 생성**
   - Databases → Create → Database
   - Name: test_db
   - Save

모든 단계가 성공하면 개발 환경 준비 완료! 🎉

---

**문제 발생시**: 
- 스크린샷과 함께 멘토에게 문의
- 에러 메시지 전체를 복사해서 공유
