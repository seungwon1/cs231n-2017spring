# ML Systems Design 클래스 - Session 7 실습 가이드
## 🎯 API 서버 구축 → DB 연동 → Streamlit 웹 페이지 만들기

### 📌 오늘의 목표
1. FastAPI 서버 정상 작동 확인
2. PostgreSQL DB 연결 및 테이블 생성
3. Postman으로 API 테스트 및 DB 저장 확인
4. Streamlit으로 간단한 예측 웹페이지 구현

---

## 🔧 Part 0: 환경 점검 및 준비

### 필수 설치 프로그램 확인
```bash
# Python 버전 확인 (3.9 이상)
python --version

# PostgreSQL 확인
psql --version

# 설치 안 된 경우:
# Windows: https://www.postgresql.org/download/windows/
# Mac: brew install postgresql
# Linux: sudo apt-get install postgresql postgresql-contrib
```

### 프로젝트 폴더 준비
```bash
# 1. 카카오톡에서 251201.zip 다운로드
# 2. 압축 해제
# 3. 터미널에서 폴더로 이동
cd 251201

# 4. 폴더 구조 확인
ls -la
# 다음 파일들이 있어야 함:
# - preprocessor.py
# - predictor.py  
# - train_model.py
# - simple_api_with_db.py
# - requirements.txt
# - data/ (폴더)
```

---

## 📦 Part 1: 패키지 설치 및 모델 학습

### Step 1-1: 가상환경 생성 (권장)
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python -m venv venv
source venv/bin/activate
```

### Step 1-2: 패키지 설치
```bash
# requirements.txt 내용 확인
cat requirements.txt

# 패키지 설치
pip install -r requirements.txt

# 설치 확인
pip list | grep -E "fastapi|streamlit|psycopg2|pandas|scikit-learn"
```

**⚠️ 설치 오류 해결:**
```bash
# psycopg2 오류시
pip install psycopg2-binary

# 전체 재설치
pip install fastapi[standard] uvicorn sqlalchemy alembic pandas joblib scikit-learn matplotlib seaborn psycopg2-binary streamlit plotly
```

### Step 1-3: 모델 학습
```bash
# 샘플 데이터 확인
ls data/
# gd_sample.csv 파일이 있어야 함

# 모델 학습 실행
python train_model.py --data data/gd_sample.csv --model-type random_forest
```

**✅ 성공 출력 예시:**
```
🚀 Flight Load Factor Model Training Started
============================================================
📊 Loading training data from data/gd_sample.csv
📈 Data shape: (5000, 6)
📋 Columns: ['arcft_flt_schd_ymd', 'arcft_flt_schd_hm', ...]

🤖 Initializing random_forest model...
📄 Preprocessing data...
📊 Training set: (4000, 11)
📊 Test set: (1000, 11)

🎯 Training random_forest model...
💾 Saving model components...
✅ Preprocessor saved to model_weights/preprocessor.joblib
✅ Predictor saved to model_weights/predictor.joblib
✅ Metadata saved to model_weights/model_metadata.json

============================================================
🎉 TRAINING COMPLETED SUCCESSFULLY
============================================================
```

**⚠️ 확인사항:**
```bash
# model_weights 폴더 확인
ls model_weights/
# 3개 파일이 있어야 함:
# - preprocessor.joblib
# - predictor.joblib  
# - model_metadata.json
```

---

## 🗄️ Part 2: PostgreSQL 데이터베이스 설정

### Step 2-1: PostgreSQL 서비스 시작
```bash
# Windows (관리자 권한 CMD)
net start postgresql-x64-15

# Mac
brew services start postgresql

# Linux
sudo systemctl start postgresql
```

### Step 2-2: pgAdmin 실행 및 데이터베이스 생성

1. **pgAdmin 실행**
   - Windows: 시작 메뉴 → pgAdmin 4
   - Mac/Linux: 애플리케이션 → pgAdmin

2. **서버 연결**
   - Servers → PostgreSQL 15 → 우클릭 → Connect
   - 비밀번호 입력

3. **데이터베이스 생성**
   - Databases → 우클릭 → Create → Database
   - Database name: `flight_load_predictor`
   - Save 클릭

### Step 2-3: 테이블 생성

1. **Query Tool 열기**
   - `flight_load_predictor` 데이터베이스 우클릭
   - Query Tool 선택

2. **테이블 생성 SQL 실행**
```sql
-- 예측 로그 테이블 생성
CREATE TABLE IF NOT EXISTS prediction_logs (
    id SERIAL PRIMARY KEY,
    flight_number VARCHAR(10),
    flight_date INTEGER,
    flight_time INTEGER,
    predicted_load_factor FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스 생성 (성능 향상)
CREATE INDEX IF NOT EXISTS idx_prediction_logs_flight 
ON prediction_logs(flight_number);

CREATE INDEX IF NOT EXISTS idx_prediction_logs_date 
ON prediction_logs(flight_date);

-- 테이블 생성 확인
SELECT * FROM prediction_logs;
```

3. **실행 결과 확인**
   - Messages 탭: "CREATE TABLE" 메시지
   - Data Output 탭: 빈 테이블 (컬럼명만 표시)

---

## 🚀 Part 3: API 서버 설정 및 실행

### Step 3-1: DB 연결 정보 수정

**`simple_api_with_db.py` 파일 수정:**
```python
# 파일 열기 (VSCode, PyCharm, 또는 텍스트 에디터)
# 15-21번 라인 근처 찾기

DB_CONFIG = {
    'host': 'localhost',
    'port': '5432',
    'database': 'flight_load_predictor',
    'user': 'postgres',
    'password': 'your_password'  # ← 여기에 실제 PostgreSQL 비밀번호 입력!
}
```

### Step 3-2: API 서버 실행
```bash
# 251201 폴더에서 실행
python simple_api_with_db.py --model-dir model_weights
```

**✅ 정상 실행 메시지:**
```
INFO:     Started server process [12345]
INFO:     Waiting for application startup.
✅ Connected to PostgreSQL successfully!
✅ Model loaded from model_weights
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
```

**⚠️ 오류 해결:**
```bash
# 포트 충돌시
python simple_api_with_db.py --model-dir model_weights --port 8080

# DB 연결 실패시
# 1. PostgreSQL 서비스 실행 확인
# 2. 비밀번호 다시 확인
# 3. 데이터베이스 이름 확인
```

### Step 3-3: 브라우저 확인
1. Chrome 또는 Edge 열기
2. http://localhost:8000 접속
3. "Welcome to Flight Load Predictor API" 메시지 확인
4. http://localhost:8000/docs 접속 → API 문서 확인

---

## 🧪 Part 4: Postman으로 API 테스트

### Step 4-1: Postman 설정

1. **Postman 실행**
2. **새 Request 생성**
   - Collections → + → Add request
   - Name: "Flight Prediction Test"

3. **Request 설정**
   ```
   Method: POST
   URL: http://localhost:8000/predict
   ```

4. **Headers 탭**
   ```
   Key: Content-Type
   Value: application/json
   ```

5. **Body 탭**
   - raw 선택
   - JSON 선택
   - 다음 내용 입력:
   ```json
   {
       "arcft_flt_schd_ymd": 20251124,
       "arcft_flt_schd_hm": 1430,
       "flt_fltnm": "KE001"
   }
   ```

### Step 4-2: 예측 요청 전송

1. **Send 버튼 클릭**
2. **응답 확인 (하단 Response 영역)**
   ```json
   {
       "flight_info": {
           "arcft_flt_schd_ymd": 20251124,
           "arcft_flt_schd_hm": 1430,
           "flt_fltnm": "KE001"
       },
       "predicted_load_factor": 0.7842,
       "prediction_time": "2024-11-24T14:30:00"
   }
   ```

### Step 4-3: DB 저장 확인

1. **pgAdmin으로 돌아가기**
2. **Query Tool에서 실행:**
   ```sql
   SELECT * FROM prediction_logs ORDER BY created_at DESC;
   ```

3. **결과 확인:**
   - 방금 예측한 KE001 항공편 정보가 저장되어 있어야 함
   - predicted_load_factor 값 확인

### Step 4-4: 다양한 테스트

**테스트 1: 다른 항공편**
```json
{
    "arcft_flt_schd_ymd": 20251125,
    "arcft_flt_schd_hm": 800,
    "flt_fltnm": "OZ101"
}
```

**테스트 2: 배치 예측**
- URL: `http://localhost:8000/predict/batch`
```json
{
    "flights": [
        {"arcft_flt_schd_ymd": 20251124, "arcft_flt_schd_hm": 800, "flt_fltnm": "KE001"},
        {"arcft_flt_schd_ymd": 20251124, "arcft_flt_schd_hm": 1200, "flt_fltnm": "OZ101"},
        {"arcft_flt_schd_ymd": 20251124, "arcft_flt_schd_hm": 1600, "flt_fltnm": "LJ263"}
    ]
}
```

**테스트 3: 로그 조회**
- Method: GET
- URL: `http://localhost:8000/logs?limit=5`

---

## 🎨 Part 5: Streamlit 웹페이지 만들기

### Step 5-1: 간단한 예측 페이지 생성

**`app_simple.py` 파일 생성:**
```python
import streamlit as st
import requests
import pandas as pd
from datetime import datetime, time

# 페이지 설정
st.set_page_config(
    page_title="✈️ 항공편 탑승률 예측",
    page_icon="✈️",
    layout="centered"
)

# 제목
st.title("✈️ 항공편 탑승률 예측 시스템")
st.markdown("간단한 예측 테스트 페이지")

# API 서버 URL
API_URL = "http://localhost:8000"

# API 상태 체크
st.sidebar.header("🔌 API 서버 상태")
if st.sidebar.button("연결 테스트"):
    try:
        response = requests.get(f"{API_URL}/status")
        if response.status_code == 200:
            st.sidebar.success("✅ API 서버 정상 작동")
        else:
            st.sidebar.error("❌ API 서버 응답 없음")
    except:
        st.sidebar.error("❌ API 서버 연결 실패")

st.divider()

# 예측 입력 폼
st.header("📝 항공편 정보 입력")

col1, col2 = st.columns(2)

with col1:
    # 날짜 입력
    flight_date = st.date_input(
        "운항 날짜",
        value=datetime(2025, 11, 24)
    )
    
    # 시간 입력
    flight_time = st.time_input(
        "운항 시간",
        value=time(14, 30)
    )

with col2:
    # 항공편명 입력
    flight_number = st.text_input(
        "항공편명",
        value="KE001",
        help="예: KE001, OZ101, LJ263"
    )
    
    # 예측 버튼
    st.write("")  # 공백
    st.write("")  # 공백
    predict_button = st.button(
        "🔮 예측하기",
        use_container_width=True,
        type="primary"
    )

# 예측 실행
if predict_button:
    # 날짜/시간 변환
    date_int = int(flight_date.strftime("%Y%m%d"))
    time_int = int(flight_time.strftime("%H%M"))
    
    # API 요청 데이터
    request_data = {
        "arcft_flt_schd_ymd": date_int,
        "arcft_flt_schd_hm": time_int,
        "flt_fltnm": flight_number
    }
    
    # 로딩 표시
    with st.spinner("예측 중..."):
        try:
            # API 호출
            response = requests.post(
                f"{API_URL}/predict",
                json=request_data
            )
            
            if response.status_code == 200:
                # 결과 파싱
                result = response.json()
                load_factor = result["predicted_load_factor"]
                
                # 성공 메시지
                st.success("✅ 예측 완료!")
                
                # 결과 표시
                st.divider()
                st.header("📊 예측 결과")
                
                # 메트릭 표시
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric(
                        "항공편",
                        flight_number
                    )
                
                with col2:
                    st.metric(
                        "예상 탑승률",
                        f"{load_factor:.1%}"
                    )
                
                with col3:
                    # 탑승률 수준 판단
                    if load_factor > 0.8:
                        level = "높음 🔴"
                    elif load_factor > 0.6:
                        level = "보통 🟡"
                    else:
                        level = "낮음 🟢"
                    
                    st.metric(
                        "탑승률 수준",
                        level
                    )
                
                # Progress bar로 시각화
                st.progress(load_factor)
                
                # 상세 정보
                with st.expander("📋 상세 정보 보기"):
                    st.json(result)
                    
                    # 요청 정보도 표시
                    st.write("**요청 데이터:**")
                    st.json(request_data)
                
            else:
                st.error(f"❌ 예측 실패 (상태 코드: {response.status_code})")
                
        except requests.exceptions.ConnectionError:
            st.error("❌ API 서버에 연결할 수 없습니다. 서버가 실행 중인지 확인하세요.")
        except Exception as e:
            st.error(f"❌ 오류 발생: {str(e)}")

# 하단 정보
st.divider()
st.caption("ML Systems Design 클래스 - Session 7")
st.caption("💡 팁: API 서버가 실행 중이어야 예측이 가능합니다.")
```

### Step 5-2: Streamlit 실행

**새 터미널 창 열기** (API 서버는 계속 실행 중이어야 함)
```bash
# 251201 폴더에서
streamlit run app_simple.py
```

**✅ 성공 메시지:**
```
  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
  Network URL: http://192.168.x.x:8501
```

### Step 5-3: 웹페이지 테스트

1. **브라우저에서 http://localhost:8501 접속**
2. **사이드바에서 "연결 테스트" 클릭**
   - ✅ API 서버 정상 작동 메시지 확인

3. **예측 테스트**
   - 날짜: 2025-11-24
   - 시간: 14:30
   - 항공편명: KE001
   - "예측하기" 버튼 클릭

4. **결과 확인**
   - 예상 탑승률 표시
   - Progress bar 시각화
   - 상세 정보 확인

### Step 5-4: DB 확인

pgAdmin에서 다시 확인:
```sql
-- Streamlit에서 예측한 내용이 저장되었는지 확인
SELECT * FROM prediction_logs 
ORDER BY created_at DESC 
LIMIT 10;
```

---
# Step 6: Docker 배포 가이드
## 🐳 On-Premise Docker 환경에서 ML 서비스 배포하기

### 📌 목표
- Backend (FastAPI) + Frontend (Streamlit)을 Docker로 컨테이너화
- Docker Compose로 한 번에 실행
- 30분 안에 완전한 서비스 배포

---

## 🔧 사전 준비

### Docker 설치 확인
```bash
# Docker 버전 확인
docker --version
# Docker Compose 버전 확인
docker compose version

# 설치 안 되어 있으면:
# Windows/Mac: Docker Desktop 설치 (https://www.docker.com/products/docker-desktop)
# Linux: 
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

### 프로젝트 구조 확인
```
251117/
├── model_weights/           # 학습된 모델
│   ├── preprocessor.joblib
│   ├── predictor.joblib
│   └── model_metadata.json
├── simple_api_with_db.py   # Backend API
├── app_advanced.py          # Frontend Streamlit
├── preprocessor.py
├── predictor.py
├── requirements.txt
└── data/
```

---

## 📦 Step 1: Backend Dockerfile 생성

**`Dockerfile.backend` 파일 생성:**
```dockerfile
# Python 3.11 slim 이미지 사용
FROM python:3.11-slim

# 작업 디렉토리 설정
WORKDIR /app

# 시스템 패키지 업데이트 및 PostgreSQL 클라이언트 설치
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# 필요한 파일만 복사
COPY requirements.txt .
COPY preprocessor.py .
COPY predictor.py .
COPY simple_api_with_db.py .

# 의존성 설치
RUN pip install --no-cache-dir -r requirements.txt

# 모델 파일 복사
COPY model_weights/ ./model_weights/

# 포트 노출
EXPOSE 8000

# 환경 변수 설정
ENV PYTHONUNBUFFERED=1

# API 서버 실행
CMD ["python", "simple_api_with_db.py", "--model-dir", "model_weights", "--host", "0.0.0.0", "--port", "8000"]
```

---

## 🎨 Step 2: Frontend Dockerfile 생성

**`Dockerfile.frontend` 파일 생성:**
```dockerfile
# Python 3.11 slim 이미지 사용
FROM python:3.11-slim

# 작업 디렉토리 설정
WORKDIR /app

# 시스템 패키지 업데이트
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# requirements 파일 생성 (Streamlit용)
RUN echo "streamlit==1.28.2" > requirements_streamlit.txt && \
    echo "pandas==2.1.3" >> requirements_streamlit.txt && \
    echo "numpy==1.24.3" >> requirements_streamlit.txt && \
    echo "plotly==5.18.0" >> requirements_streamlit.txt && \
    echo "requests==2.31.0" >> requirements_streamlit.txt && \
    echo "openpyxl==3.1.2" >> requirements_streamlit.txt

# 의존성 설치
RUN pip install --no-cache-dir -r requirements_streamlit.txt

# Streamlit 앱 복사
COPY app_advanced.py .

# Streamlit 설정 파일 생성
RUN mkdir -p ~/.streamlit && \
    echo "[server]\nheadless = true\nenableCORS = false\nport = 8501" > ~/.streamlit/config.toml

# 포트 노출
EXPOSE 8501

# Streamlit 실행
CMD ["streamlit", "run", "app_advanced.py", "--server.address", "0.0.0.0"]
```

---

## 🔄 Step 3: Docker Compose 설정

**`docker-compose.yml` 파일 생성:**
```yaml
version: '3.8'

services:
  # PostgreSQL 데이터베이스
  postgres:
    image: postgres:15-alpine
    container_name: ml_postgres
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres123
      POSTGRES_DB: flight_load_predictor
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql
    networks:
      - ml_network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Backend API 서버
  backend:
    build:
      context: .
      dockerfile: Dockerfile.backend
    container_name: ml_backend
    ports:
      - "8000:8000"
    environment:
      DB_HOST: postgres
      DB_PORT: 5432
      DB_NAME: flight_load_predictor
      DB_USER: postgres
      DB_PASSWORD: postgres123
    depends_on:
      postgres:
        condition: service_healthy
    networks:
      - ml_network
    healthcheck:
      test: ["CMD", "python", "-c", "import requests; requests.get('http://localhost:8000/status')"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Frontend Streamlit 앱
  frontend:
    build:
      context: .
      dockerfile: Dockerfile.frontend
    container_name: ml_frontend
    ports:
      - "8501:8501"
    environment:
      API_URL: http://backend:8000
    depends_on:
      backend:
        condition: service_healthy
    networks:
      - ml_network
    volumes:
      # API URL을 동적으로 설정하기 위한 환경 변수 파일
      - ./app_config.py:/app/app_config.py

networks:
  ml_network:
    driver: bridge

volumes:
  postgres_data:
```

---

## 📝 Step 4: 초기화 SQL 생성

**`init.sql` 파일 생성:**
```sql
-- 테이블 생성
CREATE TABLE IF NOT EXISTS prediction_logs (
    id SERIAL PRIMARY KEY,
    flight_number VARCHAR(10),
    flight_date INTEGER,
    flight_time INTEGER,
    predicted_load_factor FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스 생성
CREATE INDEX IF NOT EXISTS idx_prediction_logs_flight ON prediction_logs(flight_number);
CREATE INDEX IF NOT EXISTS idx_prediction_logs_date ON prediction_logs(flight_date);

-- 초기 데이터 (선택사항)
INSERT INTO prediction_logs (flight_number, flight_date, flight_time, predicted_load_factor) 
VALUES 
    ('KE001', 20251124, 800, 0.75),
    ('OZ101', 20251124, 1200, 0.82),
    ('LJ263', 20251124, 1600, 0.68);
```

---

## 🎯 Step 5: Frontend 설정 파일

**`app_config.py` 파일 생성:**
```python
import os

# Docker 환경에서는 backend 서비스명 사용
# 로컬 환경에서는 localhost 사용
API_URL = os.getenv('API_URL', 'http://backend:8000')
```

**`app_advanced.py` 수정 (상단 부분만):**
```python
# 파일 상단에 추가
try:
    from app_config import API_URL
except ImportError:
    API_URL = "http://localhost:8000"
```

---

## 🚀 Step 6: Docker 이미지 빌드 및 실행

### 1. 이미지 빌드
```bash
# 개별 빌드
docker build -f Dockerfile.backend -t ml-backend:latest .
docker build -f Dockerfile.frontend -t ml-frontend:latest .

# 또는 Docker Compose로 한번에 빌드
docker compose build
```

### 2. 컨테이너 실행
```bash
# 백그라운드에서 실행
docker compose up -d

# 로그 확인
docker compose logs -f

# 개별 서비스 로그
docker compose logs backend
docker compose logs frontend
docker compose logs postgres
```

### 3. 서비스 확인
```bash
# 실행 중인 컨테이너 확인
docker compose ps

# 출력 예시:
# NAME            IMAGE           STATUS      PORTS
# ml_postgres     postgres:15     Up          0.0.0.0:5432->5432/tcp
# ml_backend      ml-backend      Up          0.0.0.0:8000->8000/tcp
# ml_frontend     ml-frontend     Up          0.0.0.0:8501->8501/tcp
```

---

## ✅ Step 7: 서비스 테스트

### 1. Backend API 테스트
```bash
# Health Check
curl http://localhost:8000/status

# 예측 테스트
curl -X POST "http://localhost:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "arcft_flt_schd_ymd": 20251124,
    "arcft_flt_schd_hm": 1430,
    "flt_fltnm": "KE001"
  }'
```

### 2. Frontend 접속
- 브라우저에서 http://localhost:8501 접속
- Streamlit 앱이 정상 로드되는지 확인
- API 연결 테스트 실행

### 3. Database 확인
```bash
# PostgreSQL 컨테이너 접속
docker exec -it ml_postgres psql -U postgres -d flight_load_predictor

# 테이블 확인
\dt

# 데이터 조회
SELECT * FROM prediction_logs;
```

---

## 🔧 유용한 Docker 명령어

### 서비스 관리
```bash
# 서비스 중지
docker compose down

# 서비스 중지 및 볼륨 삭제
docker compose down -v

# 서비스 재시작
docker compose restart

# 특정 서비스만 재시작
docker compose restart backend
```

### 디버깅
```bash
# 컨테이너 내부 접속
docker exec -it ml_backend /bin/bash
docker exec -it ml_frontend /bin/bash

# 실시간 로그 모니터링
docker compose logs -f backend

# 리소스 사용량 확인
docker stats
```

### 이미지 관리
```bash
# 이미지 목록
docker images

# 불필요한 이미지 삭제
docker image prune -a

# 특정 이미지 삭제
docker rmi ml-backend:latest
```

---

## 🏭 Production 최적화

### 1. 멀티 스테이지 빌드 (Dockerfile.backend.prod)
```dockerfile
# Build stage
FROM python:3.11-slim as builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

# Runtime stage
FROM python:3.11-slim
WORKDIR /app
COPY --from=builder /root/.local /root/.local
COPY . .
ENV PATH=/root/.local/bin:$PATH
CMD ["python", "simple_api_with_db.py"]
```

### 2. 환경별 설정 (docker-compose.prod.yml)
```yaml
version: '3.8'

services:
  backend:
    image: ml-backend:prod
    restart: always
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '1'
          memory: 1G

  frontend:
    image: ml-frontend:prod
    restart: always
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
```

---

## 🎉 완료 체크리스트

- [ ] Docker와 Docker Compose 설치 확인
- [ ] Dockerfile.backend 생성
- [ ] Dockerfile.frontend 생성
- [ ] docker-compose.yml 생성
- [ ] init.sql 생성
- [ ] `docker compose build` 실행
- [ ] `docker compose up -d` 실행
- [ ] http://localhost:8000/status 접속 확인
- [ ] http://localhost:8501 접속 확인
- [ ] 예측 기능 테스트
- [ ] PostgreSQL 데이터 저장 확인

---

## 🐛 트러블슈팅

### 문제 1: 포트 충돌
```bash
# 포트 사용 확인
netstat -an | grep 8000
netstat -an | grep 8501
netstat -an | grep 5432

# docker-compose.yml에서 포트 변경
ports:
  - "8001:8000"  # 외부포트:내부포트
```

### 문제 2: 메모리 부족
```bash
# Docker Desktop 메모리 할당 증가
# Settings → Resources → Memory: 4GB 이상

# 또는 컨테이너별 리소스 제한
docker compose --compatibility up
```

### 문제 3: 네트워크 연결 오류
```bash
# 네트워크 재생성
docker compose down
docker network prune
docker compose up -d
```

### 문제 4: 빌드 캐시 문제
```bash
# 캐시 없이 재빌드
docker compose build --no-cache
```

---

## 📚 참고 자료

- [Docker 공식 문서](https://docs.docker.com)
- [Docker Compose 문서](https://docs.docker.com/compose)
- [FastAPI Docker 가이드](https://fastapi.tiangolo.com/deployment/docker)
- [Streamlit Docker 배포](https://docs.streamlit.io/deploy/tutorials/docker)

---

**시간 예상**: 
- Docker 설치: 5분
- 파일 생성: 10분
- 빌드 및 실행: 10분
- 테스트: 5분
- **총 30분**

**다음 단계**: Kubernetes 배포 또는 클라우드 배포 (AWS/GCP/Azure)


## ✅ 최종 체크리스트

### 1. API 서버 체크
- [ ] model_weights 폴더에 3개 파일 존재
- [ ] simple_api_with_db.py에 DB 비밀번호 설정
- [ ] API 서버 실행 (포트 8000)
- [ ] http://localhost:8000 접속 가능
- [ ] http://localhost:8000/docs 문서 확인

### 2. PostgreSQL 체크
- [ ] flight_load_predictor 데이터베이스 생성
- [ ] prediction_logs 테이블 생성
- [ ] 인덱스 생성 완료

### 3. Postman 테스트 체크
- [ ] POST /predict 엔드포인트 테스트
- [ ] 응답에 predicted_load_factor 포함
- [ ] DB에 로그 저장 확인

### 4. Streamlit 체크
- [ ] app_simple.py 파일 생성
- [ ] Streamlit 서버 실행 (포트 8501)
- [ ] API 연결 테스트 성공
- [ ] 예측 기능 정상 작동
- [ ] 결과 시각화 표시

---

## 🔧 트러블슈팅

### 자주 발생하는 문제와 해결법

**1. ModuleNotFoundError**
```bash
# 패키지 재설치
pip install -r requirements.txt
```

**2. PostgreSQL 연결 실패**
```bash
# 서비스 재시작
sudo systemctl restart postgresql  # Linux
brew services restart postgresql   # Mac
net stop postgresql-x64-15 && net start postgresql-x64-15  # Windows
```

**3. 포트 충돌**
```bash
# 사용 중인 포트 확인
netstat -an | grep 8000  # Linux/Mac
netstat -an | findstr 8000  # Windows

# 다른 포트 사용
python simple_api_with_db.py --port 8080
```

**4. Streamlit 연결 오류**
```python
# app_simple.py에서 API URL 확인
API_URL = "http://localhost:8000"  # 포트 번호 확인
```

**5. 예측 결과가 이상한 경우**
```bash
# 모델 재학습
python train_model.py --data data/gd_sample.csv --model-type random_forest
```

---

## 📚 추가 학습 자료

### Streamlit 개선 아이디어
1. 여러 항공편 동시 예측
2. 예측 히스토리 표시
3. 차트 추가 (시간대별 탑승률)
4. CSV 파일 업로드 기능

### 다음 단계
1. 더 복잡한 Streamlit 대시보드
2. 실시간 모니터링
3. 모델 성능 시각화
4. A/B 테스트 인터페이스

---

**문의사항**: 멘토에게 질문
**슬랙**: #ml-systems-design
