-- 테이블 생성
CREATE TABLE IF NOT EXISTS prediction_logs (
    id SERIAL PRIMARY KEY,
    flight_number VARCHAR(10),
    flight_date INTEGER,
    flight_time INTEGER,
    predicted_load_factor FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스 생성
CREATE INDEX IF NOT EXISTS idx_prediction_logs_flight ON prediction_logs(flight_number);
CREATE INDEX IF NOT EXISTS idx_prediction_logs_date ON prediction_logs(flight_date);
