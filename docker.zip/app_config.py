import os

# Docker 환경에서는 backend 서비스명 사용
# 로컬 환경에서는 localhost 사용
API_URL = os.getenv('API_URL', 'http://backend:8000')