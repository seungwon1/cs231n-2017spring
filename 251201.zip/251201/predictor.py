from typing import Dict, Tuple, Any, Optional, Union
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import cross_val_score, GridSearchCV
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')


class Predictor:
    """Base predictor class"""

    def __init__(self):
        pass


class FlightLoadPredictor(Predictor):
    """
    Flight load factor prediction using multiple regression models
    """

    def __init__(self, model_type: str = 'random_forest'):
        """
        Initialize the flight load predictor

        :param model_type: Type of model to use ('random_forest', 'gradient_boosting',
                          'linear', 'ridge', 'lasso', 'svr')
        """
        super().__init__()
        self.model_type = model_type
        self.model = None
        self.is_trained = False
        self.feature_names = None
        self.training_metrics = {}
        self.test_metrics = {}
        self.feature_importance = None

        # Initialize the specified model
        self._initialize_model()

    def _initialize_model(self):
        """Initialize the regression model based on model_type"""
        model_configs = {
            'random_forest': RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                min_samples_split=5,
                min_samples_leaf=2,
                random_state=42,
                n_jobs=-1
            ),
            'gradient_boosting': GradientBoostingRegressor(
                n_estimators=100,
                learning_rate=0.1,
                max_depth=6,
                min_samples_split=5,
                min_samples_leaf=2,
                random_state=42
            ),
            'linear': LinearRegression(),
            'ridge': Ridge(alpha=1.0, random_state=42),
            'lasso': Lasso(alpha=0.1, random_state=42, max_iter=1000),
            'svr': SVR(kernel='rbf', C=1.0, gamma='scale')
        }

        if self.model_type not in model_configs:
            raise ValueError(f"Unsupported model type: {self.model_type}. "
                             f"Supported types: {list(model_configs.keys())}")

        self.model = model_configs[self.model_type]

    def train(self, X_train: pd.DataFrame, y_train: pd.Series,
              X_test: pd.DataFrame = None, y_test: pd.Series = None,
              perform_cv: bool = True, cv_folds: int = 5) -> Dict[str, float]:
        """
        Train the regression model

        :param X_train: Training features
        :param y_train: Training target (load factors)
        :param X_test: Test features (optional, for validation metrics)
        :param y_test: Test target (optional, for validation metrics)
        :param perform_cv: Whether to perform cross-validation
        :param cv_folds: Number of cross-validation folds
        :return: Dictionary of training metrics
        """
        print(f"Training {self.model_type} model...")

        # Store feature names
        self.feature_names = list(X_train.columns)

        # Train the model
        self.model.fit(X_train, y_train)
        self.is_trained = True

        # Calculate training metrics
        y_train_pred = self.model.predict(X_train)
        self.training_metrics = self._calculate_metrics(y_train, y_train_pred, "Training")

        # Calculate test metrics if test data provided
        if X_test is not None and y_test is not None:
            y_test_pred = self.model.predict(X_test)
            self.test_metrics = self._calculate_metrics(y_test, y_test_pred, "Test")

        # Perform cross-validation
        if perform_cv:
            cv_scores = cross_val_score(self.model, X_train, y_train,
                                        cv=cv_folds, scoring='r2', n_jobs=-1)
            self.training_metrics['cv_r2_mean'] = cv_scores.mean()
            self.training_metrics['cv_r2_std'] = cv_scores.std()
            print(f"Cross-validation R² = {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")

        # Calculate feature importance for tree-based models
        if hasattr(self.model, 'feature_importances_'):
            self.feature_importance = pd.DataFrame({
                'feature': self.feature_names,
                'importance': self.model.feature_importances_
            }).sort_values('importance', ascending=False)

        # Print training results
        self._print_metrics()

        return {**self.training_metrics, **self.test_metrics}

    def _calculate_metrics(self, y_true: pd.Series, y_pred: np.ndarray,
                           prefix: str = "") -> Dict[str, float]:
        """Calculate regression metrics"""
        metrics = {
            f'{prefix.lower()}_mse': mean_squared_error(y_true, y_pred),
            f'{prefix.lower()}_rmse': np.sqrt(mean_squared_error(y_true, y_pred)),
            f'{prefix.lower()}_mae': mean_absolute_error(y_true, y_pred),
            f'{prefix.lower()}_r2': r2_score(y_true, y_pred),
        }
        return metrics

    def _print_metrics(self):
        """Print formatted metrics"""
        print("\n" + "=" * 50)
        print("MODEL PERFORMANCE METRICS")
        print("=" * 50)

        if self.training_metrics:
            print("\nTraining Metrics:")
            for key, value in self.training_metrics.items():
                if 'training' in key:
                    metric_name = key.replace('training_', '').upper()
                    print(f"  {metric_name:<6}: {value:.4f}")

        if self.test_metrics:
            print("\nTest Metrics:")
            for key, value in self.test_metrics.items():
                if 'test' in key:
                    metric_name = key.replace('test_', '').upper()
                    print(f"  {metric_name:<6}: {value:.4f}")

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Make predictions on new data

        :param X: Features to predict on
        :return: Predicted load factors
        """
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")

        # Ensure features match training data
        if list(X.columns) != self.feature_names:
            missing_features = set(self.feature_names) - set(X.columns)
            extra_features = set(X.columns) - set(self.feature_names)

            if missing_features:
                raise ValueError(f"Missing features: {missing_features}")
            if extra_features:
                print(f"Warning: Extra features will be ignored: {extra_features}")
                X = X[self.feature_names]

        predictions = self.model.predict(X)

        # Clip predictions to valid load factor range [0, 1]
        predictions = np.clip(predictions, 0, 1)

        return predictions

    def predict_with_confidence(self, X: pd.DataFrame,
                                confidence_method: str = 'std') -> Tuple[np.ndarray, np.ndarray]:
        """
        Make predictions with confidence intervals (for tree-based models)

        :param X: Features to predict on
        :param confidence_method: Method to calculate confidence ('std' or 'quantiles')
        :return: Tuple of (predictions, confidence_intervals)
        """
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")

        if self.model_type not in ['random_forest', 'gradient_boosting']:
            raise ValueError(f"Confidence intervals not supported for {self.model_type}")

        # For Random Forest, use individual tree predictions
        if self.model_type == 'random_forest':
            # Get predictions from all trees
            tree_predictions = np.array([
                tree.predict(X) for tree in self.model.estimators_
            ])

            predictions = np.mean(tree_predictions, axis=0)

            if confidence_method == 'std':
                confidence = np.std(tree_predictions, axis=0)
            else:  # quantiles
                confidence = np.percentile(tree_predictions, [25, 75], axis=0)

        else:  # gradient_boosting
            predictions = self.model.predict(X)
            # For GBM, confidence is harder to estimate, use training error as proxy
            training_error = self.training_metrics.get('training_rmse', 0.1)
            confidence = np.full(len(predictions), training_error)

        return np.clip(predictions, 0, 1), confidence

    def hyperparameter_tuning(self, X_train: pd.DataFrame, y_train: pd.Series,
                              cv_folds: int = 3, n_jobs: int = -1) -> Dict[str, Any]:
        """
        Perform hyperparameter tuning using GridSearchCV

        :param X_train: Training features
        :param y_train: Training target
        :param cv_folds: Number of CV folds
        :param n_jobs: Number of jobs for parallel processing
        :return: Best parameters and score
        """
        print(f"Performing hyperparameter tuning for {self.model_type}...")

        param_grids = {
            'random_forest': {
                'n_estimators': [50, 100, 200],
                'max_depth': [5, 10, 15, None],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4]
            },
            'gradient_boosting': {
                'n_estimators': [50, 100, 200],
                'learning_rate': [0.01, 0.1, 0.2],
                'max_depth': [3, 5, 7],
                'min_samples_split': [2, 5, 10]
            },
            'ridge': {
                'alpha': [0.1, 1.0, 10.0, 100.0]
            },
            'lasso': {
                'alpha': [0.01, 0.1, 1.0, 10.0]
            },
            'svr': {
                'C': [0.1, 1, 10],
                'gamma': ['scale', 'auto', 0.1, 1],
                'epsilon': [0.01, 0.1, 0.2]
            }
        }

        if self.model_type not in param_grids:
            print(f"No hyperparameter grid defined for {self.model_type}")
            return {}

        grid_search = GridSearchCV(
            self.model,
            param_grids[self.model_type],
            cv=cv_folds,
            scoring='r2',
            n_jobs=n_jobs,
            verbose=1
        )

        grid_search.fit(X_train, y_train)

        # Update model with best parameters
        self.model = grid_search.best_estimator_

        tuning_results = {
            'best_params': grid_search.best_params_,
            'best_score': grid_search.best_score_,
            'cv_results': grid_search.cv_results_
        }

        print(f"Best parameters: {grid_search.best_params_}")
        print(f"Best CV score: {grid_search.best_score_:.4f}")

        return tuning_results

    def plot_feature_importance(self, top_n: int = 15, figsize: Tuple[int, int] = (10, 6)):
        """
        Plot feature importance for tree-based models

        :param top_n: Number of top features to show
        :param figsize: Figure size
        """
        if self.feature_importance is None:
            print(f"Feature importance not available for {self.model_type}")
            return

        plt.figure(figsize=figsize)
        top_features = self.feature_importance.head(top_n)

        sns.barplot(data=top_features, y='feature', x='importance', orient='h')
        plt.title(f'Top {top_n} Feature Importance - {self.model_type.title()}')
        plt.xlabel('Importance')
        plt.ylabel('Features')
        plt.tight_layout()
        plt.show()

    def plot_predictions(self, X_test: pd.DataFrame, y_test: pd.Series,
                         sample_size: int = 500, figsize: Tuple[int, int] = (12, 4)):
        """
        Plot actual vs predicted values

        :param X_test: Test features
        :param y_test: Test target
        :param sample_size: Number of samples to plot
        :param figsize: Figure size
        """
        if not self.is_trained:
            print("Model must be trained before plotting predictions")
            return

        y_pred = self.predict(X_test)

        # Sample data if too large
        if len(y_test) > sample_size:
            indices = np.random.choice(len(y_test), sample_size, replace=False)
            y_test_sample = y_test.iloc[indices]
            y_pred_sample = y_pred[indices]
        else:
            y_test_sample = y_test
            y_pred_sample = y_pred

        fig, axes = plt.subplots(1, 2, figsize=figsize)

        # Scatter plot
        axes[0].scatter(y_test_sample, y_pred_sample, alpha=0.6, s=20)
        axes[0].plot([0, 1], [0, 1], 'r--', lw=2)
        axes[0].set_xlabel('Actual Load Factor')
        axes[0].set_ylabel('Predicted Load Factor')
        axes[0].set_title('Actual vs Predicted')
        axes[0].grid(True, alpha=0.3)

        # Residual plot
        residuals = y_test_sample - y_pred_sample
        axes[1].scatter(y_pred_sample, residuals, alpha=0.6, s=20)
        axes[1].axhline(y=0, color='r', linestyle='--', lw=2)
        axes[1].set_xlabel('Predicted Load Factor')
        axes[1].set_ylabel('Residuals')
        axes[1].set_title('Residual Plot')
        axes[1].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

    def save_model(self, filepath: str):
        """
        Save the trained model to disk

        :param filepath: Path to save the model
        """
        if not self.is_trained:
            raise ValueError("No trained model to save")

        model_data = {
            'model': self.model,
            'model_type': self.model_type,
            'feature_names': self.feature_names,
            'training_metrics': self.training_metrics,
            'test_metrics': self.test_metrics,
            'feature_importance': self.feature_importance,
            'timestamp': datetime.now().isoformat()
        }

        joblib.dump(model_data, filepath)
        print(f"Model saved to {filepath}")

    def load_model(self, filepath: str):
        """
        Load a trained model from disk

        :param filepath: Path to load the model from
        """
        model_data = joblib.load(filepath)

        self.model = model_data['model']
        self.model_type = model_data['model_type']
        self.feature_names = model_data['feature_names']
        self.training_metrics = model_data['training_metrics']
        self.test_metrics = model_data.get('test_metrics', model_data.get('validation_metrics', {}))
        self.feature_importance = model_data.get('feature_importance')
        self.is_trained = True

        print(f"Model loaded from {filepath}")
        print(f"Model type: {self.model_type}")
        print(f"Training timestamp: {model_data.get('timestamp', 'Unknown')}")

    def get_model_summary(self) -> Dict[str, Any]:
        """
        Get a summary of the model and its performance

        :return: Dictionary containing model summary
        """
        summary = {
            'model_type': self.model_type,
            'is_trained': self.is_trained,
            'feature_count': len(self.feature_names) if self.feature_names else 0,
            'feature_names': self.feature_names,
            'training_metrics': self.training_metrics,
            'test_metrics': self.test_metrics
        }

        if self.feature_importance is not None:
            summary['top_features'] = self.feature_importance.head(10).to_dict('records')

        return summary


class FlightLoadPredictorEnsemble:
    """
    Ensemble of multiple FlightLoadPredictor models for improved performance
    """

    def __init__(self, model_types: list = None):
        """
        Initialize ensemble with multiple models

        :param model_types: List of model types to include in ensemble
        """
        if model_types is None:
            model_types = ['random_forest', 'gradient_boosting', 'ridge']

        self.model_types = model_types
        self.models = {}
        self.weights = None
        self.is_trained = False

        # Initialize all models
        for model_type in model_types:
            self.models[model_type] = FlightLoadPredictor(model_type)

    def train(self, X_train: pd.DataFrame, y_train: pd.Series,
              X_test: pd.DataFrame = None, y_test: pd.Series = None,
              use_weights: bool = True) -> Dict[str, Dict[str, float]]:
        """
        Train all models in the ensemble

        :param X_train: Training features
        :param y_train: Training target
        :param X_test: Test features
        :param y_test: Test target
        :param use_weights: Whether to weight models by performance
        :return: Dictionary of metrics for each model
        """
        print("Training ensemble models...")
        all_metrics = {}

        for model_type in self.model_types:
            print(f"\n{'-' * 20} Training {model_type} {'-' * 20}")
            metrics = self.models[model_type].train(X_train, y_train, X_test, y_test)
            all_metrics[model_type] = metrics

        # Calculate ensemble weights based on test R²
        if use_weights and X_test is not None:
            r2_scores = {}
            for model_type in self.model_types:
                r2_key = 'test_r2'
                if r2_key in all_metrics[model_type]:
                    r2_scores[model_type] = max(all_metrics[model_type][r2_key], 0.01)  # Minimum weight

            if r2_scores:
                total_r2 = sum(r2_scores.values())
                self.weights = {k: v / total_r2 for k, v in r2_scores.items()}
                print(f"\nEnsemble weights: {self.weights}")
            else:
                self.weights = {model_type: 1 / len(self.model_types) for model_type in self.model_types}
        else:
            self.weights = {model_type: 1 / len(self.model_types) for model_type in self.model_types}

        self.is_trained = True
        return all_metrics

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Make ensemble predictions

        :param X: Features to predict on
        :return: Ensemble predictions
        """
        if not self.is_trained:
            raise ValueError("Ensemble must be trained before making predictions")

        predictions = np.zeros(len(X))

        for model_type in self.model_types:
            model_pred = self.models[model_type].predict(X)
            weight = self.weights.get(model_type, 1 / len(self.model_types))
            predictions += weight * model_pred

        return np.clip(predictions, 0, 1)


# Example usage and testing
if __name__ == "__main__":
    # This would typically use data from the AvtnDataPreprocessor
    print("FlightLoadPredictor implementation complete!")
    print("\nExample usage:")
    print("""
    from flight_load_predictor import FlightLoadPredictor
    from enhanced_avtn_preprocessor import AvtnDataPreprocessor

    # Prepare data
    preprocessor = AvtnDataPreprocessor()
    X_train, X_test, y_train, y_test = preprocessor.preprocess(data)

    # Train model
    predictor = FlightLoadPredictor('random_forest')
    predictor.train(X_train, y_train, X_test, y_test)

    # Make predictions
    predictions = predictor.predict(X_test)

    # Use ensemble
    ensemble = FlightLoadPredictorEnsemble()
    ensemble.train(X_train, y_train, X_test, y_test)
    ensemble_predictions = ensemble.predict(X_test)
    """)