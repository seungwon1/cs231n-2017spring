"""
Test script for Flight Load Predictor Inference API
Tests all endpoints and validates responses
"""

import requests
import json
import time
from typing import Dict, List


class InferenceAPITester:
    """Test client for inference API"""

    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session = requests.Session()

    def test_health_check(self) -> bool:
        """Test basic health check"""
        try:
            response = self.session.get(f"{self.base_url}/")
            data = response.json()
            print(f"✅ Health check: {data['status']}")
            print(f"   Model loaded: {data['model_loaded']}")
            return response.status_code == 200
        except Exception as e:
            print(f"❌ Health check failed: {e}")
            return False

    def test_status(self) -> Dict:
        """Test model status endpoint"""
        try:
            response = self.session.get(f"{self.base_url}/status")
            data = response.json()

            print(f"📊 Model Status:")
            print(f"   Loaded: {data['model_loaded']}")
            if data['model_loaded']:
                print(f"   Type: {data.get('model_type', 'N/A')}")
                print(f"   Features: {data.get('feature_count', 'N/A')}")
                print(f"   Test R²: {data.get('test_r2', 'N/A')}")
                print(f"   Test MAE: {data.get('test_mae', 'N/A')}")
                print(f"   Training: {data.get('training_date', 'N/A')}")

            return data
        except Exception as e:
            print(f"❌ Status check failed: {e}")
            return {}

    def test_single_prediction(self) -> bool:
        """Test single flight prediction"""
        try:
            # Sample flight data
            flight_data = {
                "arcft_flt_schd_ymd": 20251115,
                "arcft_flt_schd_hm": 1430,
                "flt_fltnm": "LJ263"
            }

            start_time = time.time()
            response = self.session.post(f"{self.base_url}/predict", json=flight_data)
            end_time = time.time()

            if response.status_code == 200:
                data = response.json()
                print(f"✅ Single prediction successful:")
                print(f"   Flight: {data['flight_info']['flt_fltnm']}")
                print(f"   Date: {data['flight_info']['arcft_flt_schd_ymd']}")
                print(f"   Time: {data['flight_info']['arcft_flt_schd_hm']:04d}")
                print(f"   Predicted Load Factor: {data['predicted_load_factor']:.1%}")
                print(f"   Response time: {(end_time - start_time) * 1000:.1f}ms")
                return True
            else:
                print(f"❌ Single prediction failed: {response.status_code}")
                print(f"   Error: {response.text}")
                return False

        except Exception as e:
            print(f"❌ Single prediction error: {e}")
            return False

    def test_batch_prediction(self) -> bool:
        """Test batch prediction"""
        try:
            # Multiple flights
            flights = [
                {
                    "arcft_flt_schd_ymd": 20251115,
                    "arcft_flt_schd_hm": 800,
                    "flt_fltnm": "KE001"
                },
                {
                    "arcft_flt_schd_ymd": 20251115,
                    "arcft_flt_schd_hm": 1200,
                    "flt_fltnm": "OZ101"
                },
                {
                    "arcft_flt_schd_ymd": 20251115,
                    "arcft_flt_schd_hm": 1430,
                    "flt_fltnm": "LJ263"
                },
                {
                    "arcft_flt_schd_ymd": 20251115,
                    "arcft_flt_schd_hm": 1800,
                    "flt_fltnm": "7C102"
                }
            ]

            batch_data = {"flights": flights}

            start_time = time.time()
            response = self.session.post(f"{self.base_url}/predict/batch", json=batch_data)
            end_time = time.time()

            if response.status_code == 200:
                data = response.json()
                print(f"✅ Batch prediction successful:")
                print(f"   Total flights: {data['total_flights']}")
                print(f"   Average load factor: {data['avg_load_factor']:.1%}")
                print(f"   Processing time: {data['processing_time_ms']:.1f}ms")
                print(f"   Total response time: {(end_time - start_time) * 1000:.1f}ms")

                print(f"\n   Individual predictions:")
                for pred in data['predictions']:
                    flight = pred['flight_info']
                    print(
                        f"     {flight['flt_fltnm']} {flight['arcft_flt_schd_hm']:04d}: {pred['predicted_load_factor']:.1%}")

                return True
            else:
                print(f"❌ Batch prediction failed: {response.status_code}")
                print(f"   Error: {response.text}")
                return False

        except Exception as e:
            print(f"❌ Batch prediction error: {e}")
            return False

    def test_sample_endpoint(self) -> bool:
        """Test the sample test endpoint"""
        try:
            response = self.session.get(f"{self.base_url}/test")

            if response.status_code == 200:
                data = response.json()
                print(f"✅ Sample test successful:")
                print(f"   Sample prediction: {data['predicted_load_factor']:.1%}")
                return True
            else:
                print(f"❌ Sample test failed: {response.status_code}")
                return False

        except Exception as e:
            print(f"❌ Sample test error: {e}")
            return False

    def performance_test(self, num_requests: int = 100) -> Dict:
        """Performance test with multiple requests"""
        try:
            print(f"\n🚀 Performance Test ({num_requests} requests)")

            flight_data = {
                "arcft_flt_schd_ymd": 20251115,
                "arcft_flt_schd_hm": 1430,
                "flt_fltnm": "LJ263"
            }

            times = []
            successes = 0

            for i in range(num_requests):
                start_time = time.time()
                response = self.session.post(f"{self.base_url}/predict", json=flight_data)
                end_time = time.time()

                if response.status_code == 200:
                    successes += 1
                    times.append((end_time - start_time) * 1000)

                if (i + 1) % 20 == 0:
                    print(f"   Progress: {i + 1}/{num_requests}")

            if times:
                import numpy as np
                avg_time = np.mean(times)
                p95_time = np.percentile(times, 95)

                print(f"\n📈 Performance Results:")
                print(f"   Success rate: {successes}/{num_requests} ({successes / num_requests:.1%})")
                print(f"   Average response time: {avg_time:.1f}ms")
                print(f"   95th percentile: {p95_time:.1f}ms")
                print(f"   Throughput: {1000 / avg_time:.1f} requests/second")

                return {
                    'success_rate': successes / num_requests,
                    'avg_response_time_ms': avg_time,
                    'p95_response_time_ms': p95_time,
                    'throughput_rps': 1000 / avg_time
                }

        except Exception as e:
            print(f"❌ Performance test error: {e}")
            return {}

    def run_all_tests(self):
        """Run all tests"""
        print("🧪 Flight Load Predictor API Tests")
        print("=" * 50)

        # Basic connectivity
        if not self.test_health_check():
            print("❌ API not accessible. Make sure server is running.")
            return

        print()

        # Model status
        status = self.test_status()
        if not status.get('model_loaded', False):
            print("❌ Model not loaded. Make sure model weights are available.")
            return

        print()

        # Prediction tests
        print("🎯 Testing Predictions:")
        single_ok = self.test_single_prediction()
        print()

        batch_ok = self.test_batch_prediction()
        print()

        sample_ok = self.test_sample_endpoint()
        print()

        # Performance test
        if single_ok:
            perf_results = self.performance_test(50)

        # Summary
        print("\n" + "=" * 50)
        print("📋 Test Summary:")
        print(f"   Health Check: {'✅' if True else '❌'}")
        print(f"   Model Status: {'✅' if status.get('model_loaded') else '❌'}")
        print(f"   Single Prediction: {'✅' if single_ok else '❌'}")
        print(f"   Batch Prediction: {'✅' if batch_ok else '❌'}")
        print(f"   Sample Test: {'✅' if sample_ok else '❌'}")

        if all([single_ok, batch_ok, sample_ok]):
            print("\n🎉 All tests passed! API is ready for production.")
        else:
            print("\n⚠️ Some tests failed. Check the issues above.")


def test_specific_flights():
    """Test with specific Incheon Airport flights"""
    tester = InferenceAPITester()

    print("\n✈️ Testing with Incheon Airport Flights")
    print("=" * 50)

    # Typical Incheon flights
    incheon_flights = [
        {
            "arcft_flt_schd_ymd": 20251115,
            "arcft_flt_schd_hm": 630,
            "flt_fltnm": "KE001"  # Seoul to LAX
        },
        {
            "arcft_flt_schd_ymd": 20251115,
            "arcft_flt_schd_hm": 1050,
            "flt_fltnm": "OZ101"  # Seoul to Tokyo
        },
        {
            "arcft_flt_schd_ymd": 20251115,
            "arcft_flt_schd_hm": 1425,
            "flt_fltnm": "LJ263"  # Seoul to Jeju
        },
        {
            "arcft_flt_schd_ymd": 20251115,
            "arcft_flt_schd_hm": 1830,
            "flt_fltnm": "7C102"  # Seoul to Bangkok
        },
        {
            "arcft_flt_schd_ymd": 20251115,
            "arcft_flt_schd_hm": 2145,
            "flt_fltnm": "TW701"  # Seoul to Manila
        }
    ]

    batch_data = {"flights": incheon_flights}

    try:
        response = tester.session.post(f"{tester.base_url}/predict/batch", json=batch_data)

        if response.status_code == 200:
            data = response.json()

            print(f"📊 Incheon Airport Flight Predictions:")
            print(f"   Processing time: {data['processing_time_ms']:.1f}ms")
            print(f"   Average load factor: {data['avg_load_factor']:.1%}")
            print()

            # Sort by time for better display
            predictions = data['predictions']
            predictions.sort(key=lambda x: x['flight_info']['arcft_flt_schd_hm'])

            print(f"{'Flight':<8} {'Time':<6} {'Route':<15} {'Load Factor':<12}")
            print("-" * 45)

            routes = {
                'KE001': 'ICN→LAX',
                'OZ101': 'ICN→NRT',
                'LJ263': 'ICN→CJU',
                '7C102': 'ICN→BKK',
                'TW701': 'ICN→MNL'
            }

            for pred in predictions:
                flight = pred['flight_info']
                route = routes.get(flight['flt_fltnm'], 'Unknown')
                time_str = f"{flight['arcft_flt_schd_hm']:04d}"
                time_display = f"{time_str[:2]}:{time_str[2:]}"
                load_factor = f"{pred['predicted_load_factor']:.1%}"

                print(f"{flight['flt_fltnm']:<8} {time_display:<6} {route:<15} {load_factor:<12}")

        else:
            print(f"❌ Incheon flight test failed: {response.status_code}")

    except Exception as e:
        print(f"❌ Incheon flight test error: {e}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Test Flight Load Predictor API')
    parser.add_argument('--url', type=str, default='http://localhost:8000',
                        help='API base URL')
    parser.add_argument('--perf-only', action='store_true',
                        help='Run only performance test')
    parser.add_argument('--incheon-only', action='store_true',
                        help='Run only Incheon airport test')

    args = parser.parse_args()

    tester = InferenceAPITester(args.url)

    if args.perf_only:
        tester.performance_test(100)
    elif args.incheon_only:
        test_specific_flights()
    else:
        tester.run_all_tests()
        test_specific_flights()