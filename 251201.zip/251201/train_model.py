"""
Training script for Flight Load Predictor
Trains model and saves weights locally for inference server
"""

import pandas as pd
import numpy as np
import joblib
import os
from datetime import datetime
from preprocessor import AvtnDataPreprocessor
from predictor import FlightLoadPredictor


def train_and_save_model(data_file: str = None,
                         model_type: str = "random_forest",
                         save_dir: str = "model_weights"):
    """
    Train model and save weights locally

    :param data_file: Path to training data CSV file
    :param model_type: Type of model to train
    :param save_dir: Directory to save model weights
    """
    print("🚀 Flight Load Factor Model Training Started")
    print("=" * 60)

    # Create save directory
    os.makedirs(save_dir, exist_ok=True)

    # Load or create sample data
    if data_file and os.path.exists(data_file):
        print(f"📊 Loading training data from {data_file}")
        data = pd.read_csv(data_file)
    else:
        print("📊 Creating sample training data...")
        data = create_sample_data()

    print(f"📈 Data shape: {data.shape}")
    print(f"📋 Columns: {list(data.columns)}")

    # Initialize components
    print(f"\n🤖 Initializing {model_type} model...")
    preprocessor = AvtnDataPreprocessor()
    predictor = FlightLoadPredictor(model_type=model_type)

    # Preprocess and train
    print("\n🔄 Preprocessing data...")
    X_train, X_test, y_train, y_test = preprocessor.preprocess(data)

    print(f"📊 Training set: {X_train.shape}")
    print(f"📊 Test set: {X_test.shape}")

    # Train model
    print(f"\n🎯 Training {model_type} model...")
    metrics = predictor.train(X_train, y_train, X_test, y_test)

    # Save model components
    model_files = {
        'preprocessor': f"{save_dir}/preprocessor.joblib",
        'predictor': f"{save_dir}/predictor.joblib",
        'metadata': f"{save_dir}/model_metadata.json"
    }

    print("\n💾 Saving model components...")

    # Save preprocessor
    joblib.dump(preprocessor, model_files['preprocessor'])
    print(f"✅ Preprocessor saved to {model_files['preprocessor']}")

    # Save predictor
    joblib.dump(predictor, model_files['predictor'])
    print(f"✅ Predictor saved to {model_files['predictor']}")

    # Save metadata
    metadata = {
        'model_type': model_type,
        'training_date': datetime.now().isoformat(),
        'data_shape': data.shape,
        'feature_names': predictor.feature_names,
        'metrics': metrics,
        'files': model_files
    }

    import json
    with open(model_files['metadata'], 'w') as f:
        json.dump(metadata, f, indent=2)
    print(f"✅ Metadata saved to {model_files['metadata']}")

    # Print summary
    print("\n" + "=" * 60)
    print("🎉 TRAINING COMPLETED SUCCESSFULLY")
    print("=" * 60)
    print(f"📈 Model Performance:")
    print(f"   - Test R²: {metrics.get('test_r2', 0):.4f}")
    print(f"   - Test RMSE: {metrics.get('test_rmse', 0):.4f}")
    print(f"   - Test MAE: {metrics.get('test_mae', 0):.4f}")

    print(f"\n📂 Model files saved in: {save_dir}/")
    for name, path in model_files.items():
        print(f"   - {name}: {path}")

    print(f"\n🚀 Ready for inference server!")
    print(f"   Run: python simple_api_server.py --model-dir {save_dir}")

    return model_files, metadata


def create_sample_data(n_samples: int = 5000):
    """Create sample training data for testing"""
    print("🔄 Generating sample data...")

    np.random.seed(42)

    # Date range: last 6 months
    dates = pd.date_range('2024-05-01', '2024-10-31', freq='D')

    data = []
    flight_codes = ['KE001', 'OZ101', 'LJ263', '7C102', 'TW701', 'ZE201', 'BX101']
    times = [600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200]

    for i in range(n_samples):
        date = np.random.choice(dates)
        flight = np.random.choice(flight_codes)
        time = np.random.choice(times)

        # Aircraft capacity based on flight type
        if flight.startswith('KE') or flight.startswith('OZ'):  # Legacy carriers
            capacity = np.random.randint(250, 350)
        else:  # LCC
            capacity = np.random.randint(150, 250)

        # Generate realistic load factors based on time/day patterns
        base_load = 0.6

        # Time of day effect
        if time in [800, 1800, 2000]:  # Peak hours
            base_load += 0.2
        elif time in [1000, 1400]:  # Mid day
            base_load += 0.1

        # Day of week effect
        if date.weekday() in [0, 4]:  # Monday, Friday
            base_load += 0.15
        elif date.weekday() in [5, 6]:  # Weekend
            base_load += 0.1

        # Add noise
        base_load += np.random.normal(0, 0.1)
        base_load = np.clip(base_load, 0.1, 0.95)

        # Calculate passengers
        total_passengers = int(capacity * base_load)
        paying_passengers = int(total_passengers * 0.92)
        free_passengers = total_passengers - paying_passengers

        data.append({
            'arcft_flt_schd_ymd': int(date.strftime('%Y%m%d')),
            'arcft_flt_schd_hm': time,
            'flt_fltnm': flight,
            'arcft_sply_stgcp': capacity,
            'pfr_psg_sum_prsnm': paying_passengers,
            'free_psg_sum_prsnm': free_passengers
        })

    df = pd.DataFrame(data)
    print(f"✅ Generated {len(df)} sample records")
    return df


def train_from_csv(csv_file: str, model_type: str = "random_forest"):
    """
    Convenience function to train from CSV file

    CSV should have columns:
    - arcft_flt_schd_ymd: Flight date (YYYYMMDD)
    - arcft_flt_schd_hm: Flight time (HHMM)
    - flt_fltnm: Flight number
    - arcft_sply_stgcp: Aircraft capacity
    - pfr_psg_sum_prsnm: Paying passengers
    - free_psg_sum_prsnm: Free passengers
    """
    return train_and_save_model(csv_file, model_type)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Train Flight Load Predictor')
    parser.add_argument('--data', type=str, help='Path to training data CSV')
    parser.add_argument('--model-type', type=str, default='random_forest',
                        choices=['random_forest', 'gradient_boosting', 'ridge', 'lasso'],
                        help='Type of model to train')
    parser.add_argument('--save-dir', type=str, default='model_weights',
                        help='Directory to save model weights')

    args = parser.parse_args()

    # Train and save model
    model_files, metadata = train_and_save_model(
        data_file=args.data,
        model_type=args.model_type,
        save_dir=args.save_dir
    )

    print("\n🎯 Next steps:")
    print("1. Start inference server:")
    print(f"   python simple_api_server.py --model-dir {args.save_dir}")
    print("2. Test predictions:")
    print("   python test_inference.py")