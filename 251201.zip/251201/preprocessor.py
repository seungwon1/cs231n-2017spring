from typing import Tuple, Any, Optional
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split


class AvtnDataPreprocessor:
    """
    Preprocessor for t_ftf_avtn_stats_s
    """

    def __init__(self):
        self.flight_encoder = LabelEncoder()
        self.scaler = StandardScaler()
        self.is_fitted = False

    def preprocess(self, data: pd.DataFrame, test_size: float = 0.2,
                   random_state: int = 42, scale_features: bool = True,
                   return_raw: bool = False) -> tuple:
        """
        Complete preprocessing pipeline for aviation data

        :param data: t_ftf_avtn_stats_s
        :param test_size: Proportion of data for testing (ignored if return_raw=True)
        :param random_state: Random seed for reproducibility (ignored if return_raw=True)
        :param scale_features: Whether to scale numerical features (ignored if return_raw=True)
        :param return_raw: If True, returns raw data_x, data_y. If False, returns train/test splits
        :return: Either (data_x, data_y) or (X_train, X_test, y_train, y_test)

        Example:
            # For raw data:
            data_x, data_y = preprocessor.preprocess(data, return_raw=True)

            # For regression-ready data:
            X_train, X_test, y_train, y_test = preprocessor.preprocess(data)
        """
        # Step 1: Extract features and target
        columns = [["arcft_flt_schd_ymd", "arcft_flt_schd_hm", "flt_fltnm"],
                   ["arcft_sply_stgcp", "pfr_psg_sum_prsnm", "free_psg_sum_prsnm"]]
        data_x = data.loc[:, columns[0]].copy()

        data_y_raw = data.loc[:, columns[1]]
        data_y = (data_y_raw["pfr_psg_sum_prsnm"] + data_y_raw["free_psg_sum_prsnm"]) / data_y_raw["arcft_sply_stgcp"]

        # Step 2: Filter out null values and invalid load factors
        mask = (0 < data_y) & (data_y <= 1) & data_x.notna().all(axis=1) & data_y.notna()
        data_x = data_x[mask]
        data_y = data_y[mask]

        # Step 3: Return raw data if requested (backward compatibility)
        if return_raw:
            return data_x, data_y

        # Step 4: Call prepare_for_regression for full pipeline
        return self.prepare_for_regression(data_x, data_y, test_size, random_state, scale_features)

    def encode_flight_code(self, data_x: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """
        Convert flight code (third column) from string to numerical value

        :param data_x: DataFrame with flight data including flight codes
        :param fit: Whether to fit the encoder (True for training data, False for new data)
        :return: DataFrame with encoded flight codes
        """
        data_x_encoded = data_x.copy()

        if fit:
            # Fit and transform flight codes
            data_x_encoded['flt_fltnm_encoded'] = self.flight_encoder.fit_transform(data_x['flt_fltnm'])
        else:
            # Transform using already fitted encoder
            if not hasattr(self.flight_encoder, 'classes_'):
                raise ValueError("Flight encoder must be fitted before transforming new data")

            # Handle unseen flight codes by assigning them a special value
            known_flights = set(self.flight_encoder.classes_)
            flight_codes = data_x['flt_fltnm'].copy()

            # Replace unseen flight codes with the most frequent one from training
            most_frequent_flight = self.flight_encoder.classes_[0]  # Assuming first is most frequent
            flight_codes = flight_codes.apply(
                lambda x: x if x in known_flights else most_frequent_flight
            )

            data_x_encoded['flt_fltnm_encoded'] = self.flight_encoder.transform(flight_codes)

        # Drop original flight code column
        data_x_encoded = data_x_encoded.drop('flt_fltnm', axis=1)

        return data_x_encoded

    def prepare_temporal_features(self, data_x: pd.DataFrame) -> pd.DataFrame:
        """
        Convert date and time features into more meaningful numerical features

        :param data_x: DataFrame with date and time columns
        :return: DataFrame with engineered temporal features
        """
        data_x_temporal = data_x.copy()

        # Convert date to datetime for feature extraction
        data_x_temporal['date'] = pd.to_datetime(data_x_temporal['arcft_flt_schd_ymd'], format='%Y%m%d')

        # Extract temporal features
        data_x_temporal['year'] = data_x_temporal['date'].dt.year
        data_x_temporal['month'] = data_x_temporal['date'].dt.month
        data_x_temporal['day'] = data_x_temporal['date'].dt.day
        data_x_temporal['day_of_week'] = data_x_temporal['date'].dt.dayofweek  # 0=Monday
        data_x_temporal['day_of_year'] = data_x_temporal['date'].dt.dayofyear
        data_x_temporal['is_weekend'] = (data_x_temporal['day_of_week'] >= 5).astype(int)

        # Convert time to minutes and extract hour features
        data_x_temporal['hour'] = data_x_temporal['arcft_flt_schd_hm'] // 100
        data_x_temporal['minute'] = data_x_temporal['arcft_flt_schd_hm'] % 100
        data_x_temporal['total_minutes'] = data_x_temporal['hour'] * 60 + data_x_temporal['minute']

        # Time of day categories (useful for aviation)
        def get_time_category(hour):
            if 5 <= hour < 12:
                return 0  # Morning
            elif 12 <= hour < 18:
                return 1  # Afternoon
            elif 18 <= hour < 22:
                return 2  # Evening
            else:
                return 3  # Night

        data_x_temporal['time_category'] = data_x_temporal['hour'].apply(get_time_category)

        # Drop original and intermediate columns
        columns_to_drop = ['arcft_flt_schd_ymd', 'arcft_flt_schd_hm', 'date']
        data_x_temporal = data_x_temporal.drop(columns_to_drop, axis=1)

        return data_x_temporal

    def prepare_for_regression(self, data_x: pd.DataFrame, data_y: pd.Series,
                               test_size: float = 0.2, random_state: int = 42,
                               scale_features: bool = True) -> tuple:
        """
        Prepare data for regression by encoding categorical variables and scaling

        :param data_x: Feature DataFrame
        :param data_y: Target Series (load factor)
        :param test_size: Proportion of data for testing
        :param random_state: Random seed for reproducibility
        :param scale_features: Whether to scale numerical features
        :return: X_train, X_test, y_train, y_test
        """
        # Step 1: Encode flight codes
        data_x_encoded = self.encode_flight_code(data_x, fit=True)

        # Step 2: Engineer temporal features
        data_x_processed = self.prepare_temporal_features(data_x_encoded)

        # Step 3: Split the data
        X_train, X_test, y_train, y_test = train_test_split(
            data_x_processed, data_y,
            test_size=test_size,
            random_state=random_state,
            stratify=None  # Can't stratify continuous target
        )

        # Step 4: Scale features if requested
        if scale_features:
            X_train_scaled = pd.DataFrame(
                self.scaler.fit_transform(X_train),
                columns=X_train.columns,
                index=X_train.index
            )
            X_test_scaled = pd.DataFrame(
                self.scaler.transform(X_test),
                columns=X_test.columns,
                index=X_test.index
            )
            self.is_fitted = True
            return X_train_scaled, X_test_scaled, y_train, y_test
        else:
            self.is_fitted = True
            return X_train, X_test, y_train, y_test

    def transform_new_data(self, data_x: pd.DataFrame, scale_features: bool = True) -> pd.DataFrame:
        """
        Transform new data using fitted encoders and scalers

        :param data_x: New data to transform
        :param scale_features: Whether to scale features
        :return: Transformed data ready for prediction
        """
        if not self.is_fitted:
            raise ValueError("Preprocessor must be fitted before transforming new data")

        # Encode flight codes (without fitting)
        data_x_encoded = self.encode_flight_code(data_x, fit=False)

        # Engineer temporal features
        data_x_processed = self.prepare_temporal_features(data_x_encoded)

        # Scale if requested
        if scale_features:
            data_x_scaled = pd.DataFrame(
                self.scaler.transform(data_x_processed),
                columns=data_x_processed.columns,
                index=data_x_processed.index
            )
            return data_x_scaled
        else:
            return data_x_processed

    def get_feature_info(self) -> dict:
        """
        Get information about the features created by the preprocessor

        :return: Dictionary with feature information
        """
        if not self.is_fitted:
            return {"error": "Preprocessor not fitted yet"}

        info = {
            "flight_codes_count": len(self.flight_encoder.classes_),
            "sample_flight_codes": list(self.flight_encoder.classes_[:10]),
            "feature_names": [
                "flt_fltnm_encoded", "year", "month", "day", "day_of_week",
                "day_of_year", "is_weekend", "hour", "minute", "total_minutes", "time_category"
            ],
            "scaling_applied": hasattr(self.scaler, 'scale_')
        }
        return info




class DalyFltArvPreprocessor:
    """
    Preprocessor for t_ftf_daly_flt_arvac_i
    """
    def __init__(self):
        pass

    def preprocess(self, data: pd.DataFrame) -> pd.DataFrame:
        """

        :param data:
        :return:
        """
        pass



