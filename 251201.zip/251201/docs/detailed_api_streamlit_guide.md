# ML Systems Design 클래스 - Session 7 실습 가이드
## 🎯 API 서버 구축 → DB 연동 → Streamlit 웹 페이지 만들기

### 📌 오늘의 목표
1. FastAPI 서버 정상 작동 확인
2. PostgreSQL DB 연결 및 테이블 생성
3. Postman으로 API 테스트 및 DB 저장 확인
4. Streamlit으로 간단한 예측 웹페이지 구현

---

## 🔧 Part 0: 환경 점검 및 준비

### 필수 설치 프로그램 확인
```bash
# Python 버전 확인 (3.9 이상)
python --version

# PostgreSQL 확인
psql --version

# 설치 안 된 경우:
# Windows: https://www.postgresql.org/download/windows/
# Mac: brew install postgresql
# Linux: sudo apt-get install postgresql postgresql-contrib
```

### 프로젝트 폴더 준비
```bash
# 1. 카카오톡에서 251201.zip 다운로드
# 2. 압축 해제
# 3. 터미널에서 폴더로 이동
cd 251201

# 4. 폴더 구조 확인
ls -la
# 다음 파일들이 있어야 함:
# - preprocessor.py
# - predictor.py  
# - train_model.py
# - simple_api_with_db.py
# - requirements.txt
# - data/ (폴더)
```

---

## 📦 Part 1: 패키지 설치 및 모델 학습

### Step 1-1: 가상환경 생성 (권장)
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python -m venv venv
source venv/bin/activate
```

### Step 1-2: 패키지 설치
```bash
# requirements.txt 내용 확인
cat requirements.txt

# 패키지 설치
pip install -r requirements.txt

# 설치 확인
pip list | grep -E "fastapi|streamlit|psycopg2|pandas|scikit-learn"
```

**⚠️ 설치 오류 해결:**
```bash
# psycopg2 오류시
pip install psycopg2-binary

# 전체 재설치
pip install fastapi[standard] uvicorn sqlalchemy alembic pandas joblib scikit-learn matplotlib seaborn psycopg2-binary streamlit plotly
```

### Step 1-3: 모델 학습
```bash
# 샘플 데이터 확인
ls data/
# gd_sample.csv 파일이 있어야 함

# 모델 학습 실행
python train_model.py --data data/gd_sample.csv --model-type random_forest
```

**✅ 성공 출력 예시:**
```
🚀 Flight Load Factor Model Training Started
============================================================
📊 Loading training data from data/gd_sample.csv
📈 Data shape: (5000, 6)
📋 Columns: ['arcft_flt_schd_ymd', 'arcft_flt_schd_hm', ...]

🤖 Initializing random_forest model...
📄 Preprocessing data...
📊 Training set: (4000, 11)
📊 Test set: (1000, 11)

🎯 Training random_forest model...
💾 Saving model components...
✅ Preprocessor saved to model_weights/preprocessor.joblib
✅ Predictor saved to model_weights/predictor.joblib
✅ Metadata saved to model_weights/model_metadata.json

============================================================
🎉 TRAINING COMPLETED SUCCESSFULLY
============================================================
```

**⚠️ 확인사항:**
```bash
# model_weights 폴더 확인
ls model_weights/
# 3개 파일이 있어야 함:
# - preprocessor.joblib
# - predictor.joblib  
# - model_metadata.json
```

---

## 🗄️ Part 2: PostgreSQL 데이터베이스 설정

### Step 2-1: PostgreSQL 서비스 시작
```bash
# Windows (관리자 권한 CMD)
net start postgresql-x64-15

# Mac
brew services start postgresql

# Linux
sudo systemctl start postgresql
```

### Step 2-2: pgAdmin 실행 및 데이터베이스 생성

1. **pgAdmin 실행**
   - Windows: 시작 메뉴 → pgAdmin 4
   - Mac/Linux: 애플리케이션 → pgAdmin

2. **서버 연결**
   - Servers → PostgreSQL 15 → 우클릭 → Connect
   - 비밀번호 입력

3. **데이터베이스 생성**
   - Databases → 우클릭 → Create → Database
   - Database name: `flight_load_predictor`
   - Save 클릭

### Step 2-3: 테이블 생성

1. **Query Tool 열기**
   - `flight_load_predictor` 데이터베이스 우클릭
   - Query Tool 선택

2. **테이블 생성 SQL 실행**
```sql
-- 예측 로그 테이블 생성
CREATE TABLE IF NOT EXISTS prediction_logs (
    id SERIAL PRIMARY KEY,
    flight_number VARCHAR(10),
    flight_date INTEGER,
    flight_time INTEGER,
    predicted_load_factor FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스 생성 (성능 향상)
CREATE INDEX IF NOT EXISTS idx_prediction_logs_flight 
ON prediction_logs(flight_number);

CREATE INDEX IF NOT EXISTS idx_prediction_logs_date 
ON prediction_logs(flight_date);

-- 테이블 생성 확인
SELECT * FROM prediction_logs;
```

3. **실행 결과 확인**
   - Messages 탭: "CREATE TABLE" 메시지
   - Data Output 탭: 빈 테이블 (컬럼명만 표시)

---

## 🚀 Part 3: API 서버 설정 및 실행

### Step 3-1: DB 연결 정보 수정

**`simple_api_with_db.py` 파일 수정:**
```python
# 파일 열기 (VSCode, PyCharm, 또는 텍스트 에디터)
# 15-21번 라인 근처 찾기

DB_CONFIG = {
    'host': 'localhost',
    'port': '5432',
    'database': 'flight_load_predictor',
    'user': 'postgres',
    'password': 'your_password'  # ← 여기에 실제 PostgreSQL 비밀번호 입력!
}
```

### Step 3-2: API 서버 실행
```bash
# 251201 폴더에서 실행
python simple_api_with_db.py --model-dir model_weights
```

**✅ 정상 실행 메시지:**
```
INFO:     Started server process [12345]
INFO:     Waiting for application startup.
✅ Connected to PostgreSQL successfully!
✅ Model loaded from model_weights
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
```

**⚠️ 오류 해결:**
```bash
# 포트 충돌시
python simple_api_with_db.py --model-dir model_weights --port 8080

# DB 연결 실패시
# 1. PostgreSQL 서비스 실행 확인
# 2. 비밀번호 다시 확인
# 3. 데이터베이스 이름 확인
```

### Step 3-3: 브라우저 확인
1. Chrome 또는 Edge 열기
2. http://localhost:8000 접속
3. "Welcome to Flight Load Predictor API" 메시지 확인
4. http://localhost:8000/docs 접속 → API 문서 확인

---

## 🧪 Part 4: Postman으로 API 테스트

### Step 4-1: Postman 설정

1. **Postman 실행**
2. **새 Request 생성**
   - Collections → + → Add request
   - Name: "Flight Prediction Test"

3. **Request 설정**
   ```
   Method: POST
   URL: http://localhost:8000/predict
   ```

4. **Headers 탭**
   ```
   Key: Content-Type
   Value: application/json
   ```

5. **Body 탭**
   - raw 선택
   - JSON 선택
   - 다음 내용 입력:
   ```json
   {
       "arcft_flt_schd_ymd": 20251124,
       "arcft_flt_schd_hm": 1430,
       "flt_fltnm": "KE001"
   }
   ```

### Step 4-2: 예측 요청 전송

1. **Send 버튼 클릭**
2. **응답 확인 (하단 Response 영역)**
   ```json
   {
       "flight_info": {
           "arcft_flt_schd_ymd": 20251124,
           "arcft_flt_schd_hm": 1430,
           "flt_fltnm": "KE001"
       },
       "predicted_load_factor": 0.7842,
       "prediction_time": "2024-11-24T14:30:00"
   }
   ```

### Step 4-3: DB 저장 확인

1. **pgAdmin으로 돌아가기**
2. **Query Tool에서 실행:**
   ```sql
   SELECT * FROM prediction_logs ORDER BY created_at DESC;
   ```

3. **결과 확인:**
   - 방금 예측한 KE001 항공편 정보가 저장되어 있어야 함
   - predicted_load_factor 값 확인

### Step 4-4: 다양한 테스트

**테스트 1: 다른 항공편**
```json
{
    "arcft_flt_schd_ymd": 20251125,
    "arcft_flt_schd_hm": 800,
    "flt_fltnm": "OZ101"
}
```

**테스트 2: 배치 예측**
- URL: `http://localhost:8000/predict/batch`
```json
{
    "flights": [
        {"arcft_flt_schd_ymd": 20251124, "arcft_flt_schd_hm": 800, "flt_fltnm": "KE001"},
        {"arcft_flt_schd_ymd": 20251124, "arcft_flt_schd_hm": 1200, "flt_fltnm": "OZ101"},
        {"arcft_flt_schd_ymd": 20251124, "arcft_flt_schd_hm": 1600, "flt_fltnm": "LJ263"}
    ]
}
```

**테스트 3: 로그 조회**
- Method: GET
- URL: `http://localhost:8000/logs?limit=5`

---

## 🎨 Part 5: Streamlit 웹페이지 만들기

### Step 5-1: 간단한 예측 페이지 생성

**`app_simple.py` 파일 생성:**
```python
import streamlit as st
import requests
import pandas as pd
from datetime import datetime, time

# 페이지 설정
st.set_page_config(
    page_title="✈️ 항공편 탑승률 예측",
    page_icon="✈️",
    layout="centered"
)

# 제목
st.title("✈️ 항공편 탑승률 예측 시스템")
st.markdown("간단한 예측 테스트 페이지")

# API 서버 URL
API_URL = "http://localhost:8000"

# API 상태 체크
st.sidebar.header("🔌 API 서버 상태")
if st.sidebar.button("연결 테스트"):
    try:
        response = requests.get(f"{API_URL}/status")
        if response.status_code == 200:
            st.sidebar.success("✅ API 서버 정상 작동")
        else:
            st.sidebar.error("❌ API 서버 응답 없음")
    except:
        st.sidebar.error("❌ API 서버 연결 실패")

st.divider()

# 예측 입력 폼
st.header("📝 항공편 정보 입력")

col1, col2 = st.columns(2)

with col1:
    # 날짜 입력
    flight_date = st.date_input(
        "운항 날짜",
        value=datetime(2025, 11, 24)
    )
    
    # 시간 입력
    flight_time = st.time_input(
        "운항 시간",
        value=time(14, 30)
    )

with col2:
    # 항공편명 입력
    flight_number = st.text_input(
        "항공편명",
        value="KE001",
        help="예: KE001, OZ101, LJ263"
    )
    
    # 예측 버튼
    st.write("")  # 공백
    st.write("")  # 공백
    predict_button = st.button(
        "🔮 예측하기",
        use_container_width=True,
        type="primary"
    )

# 예측 실행
if predict_button:
    # 날짜/시간 변환
    date_int = int(flight_date.strftime("%Y%m%d"))
    time_int = int(flight_time.strftime("%H%M"))
    
    # API 요청 데이터
    request_data = {
        "arcft_flt_schd_ymd": date_int,
        "arcft_flt_schd_hm": time_int,
        "flt_fltnm": flight_number
    }
    
    # 로딩 표시
    with st.spinner("예측 중..."):
        try:
            # API 호출
            response = requests.post(
                f"{API_URL}/predict",
                json=request_data
            )
            
            if response.status_code == 200:
                # 결과 파싱
                result = response.json()
                load_factor = result["predicted_load_factor"]
                
                # 성공 메시지
                st.success("✅ 예측 완료!")
                
                # 결과 표시
                st.divider()
                st.header("📊 예측 결과")
                
                # 메트릭 표시
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric(
                        "항공편",
                        flight_number
                    )
                
                with col2:
                    st.metric(
                        "예상 탑승률",
                        f"{load_factor:.1%}"
                    )
                
                with col3:
                    # 탑승률 수준 판단
                    if load_factor > 0.8:
                        level = "높음 🔴"
                    elif load_factor > 0.6:
                        level = "보통 🟡"
                    else:
                        level = "낮음 🟢"
                    
                    st.metric(
                        "탑승률 수준",
                        level
                    )
                
                # Progress bar로 시각화
                st.progress(load_factor)
                
                # 상세 정보
                with st.expander("📋 상세 정보 보기"):
                    st.json(result)
                    
                    # 요청 정보도 표시
                    st.write("**요청 데이터:**")
                    st.json(request_data)
                
            else:
                st.error(f"❌ 예측 실패 (상태 코드: {response.status_code})")
                
        except requests.exceptions.ConnectionError:
            st.error("❌ API 서버에 연결할 수 없습니다. 서버가 실행 중인지 확인하세요.")
        except Exception as e:
            st.error(f"❌ 오류 발생: {str(e)}")

# 하단 정보
st.divider()
st.caption("ML Systems Design 클래스 - Session 7")
st.caption("💡 팁: API 서버가 실행 중이어야 예측이 가능합니다.")
```

### Step 5-2: Streamlit 실행

**새 터미널 창 열기** (API 서버는 계속 실행 중이어야 함)
```bash
# 251201 폴더에서
streamlit run app_simple.py
```

**✅ 성공 메시지:**
```
  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
  Network URL: http://192.168.x.x:8501
```

### Step 5-3: 웹페이지 테스트

1. **브라우저에서 http://localhost:8501 접속**
2. **사이드바에서 "연결 테스트" 클릭**
   - ✅ API 서버 정상 작동 메시지 확인

3. **예측 테스트**
   - 날짜: 2025-11-24
   - 시간: 14:30
   - 항공편명: KE001
   - "예측하기" 버튼 클릭

4. **결과 확인**
   - 예상 탑승률 표시
   - Progress bar 시각화
   - 상세 정보 확인

### Step 5-4: DB 확인

pgAdmin에서 다시 확인:
```sql
-- Streamlit에서 예측한 내용이 저장되었는지 확인
SELECT * FROM prediction_logs 
ORDER BY created_at DESC 
LIMIT 10;
```

---

## ✅ 최종 체크리스트

### 1. API 서버 체크
- [ ] model_weights 폴더에 3개 파일 존재
- [ ] simple_api_with_db.py에 DB 비밀번호 설정
- [ ] API 서버 실행 (포트 8000)
- [ ] http://localhost:8000 접속 가능
- [ ] http://localhost:8000/docs 문서 확인

### 2. PostgreSQL 체크
- [ ] flight_load_predictor 데이터베이스 생성
- [ ] prediction_logs 테이블 생성
- [ ] 인덱스 생성 완료

### 3. Postman 테스트 체크
- [ ] POST /predict 엔드포인트 테스트
- [ ] 응답에 predicted_load_factor 포함
- [ ] DB에 로그 저장 확인

### 4. Streamlit 체크
- [ ] app_simple.py 파일 생성
- [ ] Streamlit 서버 실행 (포트 8501)
- [ ] API 연결 테스트 성공
- [ ] 예측 기능 정상 작동
- [ ] 결과 시각화 표시

---

## 🔧 트러블슈팅

### 자주 발생하는 문제와 해결법

**1. ModuleNotFoundError**
```bash
# 패키지 재설치
pip install -r requirements.txt
```

**2. PostgreSQL 연결 실패**
```bash
# 서비스 재시작
sudo systemctl restart postgresql  # Linux
brew services restart postgresql   # Mac
net stop postgresql-x64-15 && net start postgresql-x64-15  # Windows
```

**3. 포트 충돌**
```bash
# 사용 중인 포트 확인
netstat -an | grep 8000  # Linux/Mac
netstat -an | findstr 8000  # Windows

# 다른 포트 사용
python simple_api_with_db.py --port 8080
```

**4. Streamlit 연결 오류**
```python
# app_simple.py에서 API URL 확인
API_URL = "http://localhost:8000"  # 포트 번호 확인
```

**5. 예측 결과가 이상한 경우**
```bash
# 모델 재학습
python train_model.py --data data/gd_sample.csv --model-type random_forest
```

---

## 📚 추가 학습 자료

### Streamlit 개선 아이디어
1. 여러 항공편 동시 예측
2. 예측 히스토리 표시
3. 차트 추가 (시간대별 탑승률)
4. CSV 파일 업로드 기능

### 다음 단계
1. 더 복잡한 Streamlit 대시보드
2. 실시간 모니터링
3. 모델 성능 시각화
4. A/B 테스트 인터페이스

---

**문의사항**: 멘토에게 질문
**슬랙**: #ml-systems-design
