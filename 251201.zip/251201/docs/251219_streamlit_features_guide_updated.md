# Streamlit 기능 확장 가이드
## 🚀 기본 예측 페이지에서 고급 기능 추가하기

### 📌 시작하기 전에
- 기본 `app_simple.py`가 정상 작동해야 합니다
- 각 기능을 하나씩 추가하면서 테스트하세요
- 코드 백업을 권장합니다: `cp app_simple.py app_simple_backup.py`

---

## 🛠️ 사전 준비: 기본 구조 변경

### Step 0: 필요한 라이브러리 추가
```python
# 기존 import에 추가
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, time, timedelta
import json
import io
```

### Step 1: 페이지 설정 변경
```python
# 기존 페이지 설정을 아래와 같이 변경
st.set_page_config(
    page_title="✈️ 인천공항 탑승률 예측 시스템",
    page_icon="✈️",
    layout="wide",  # centered → wide 변경
    initial_sidebar_state="expanded"
)
```

### Step 2: 커스텀 CSS 추가
```python
# 페이지 설정 바로 아래에 추가
st.markdown("""
<style>
    .stMetric {
        background-color: #f0f2f6;
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .metric-container {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 20px;
        border-radius: 15px;
        color: white;
    }
    div[data-testid="stSidebar"] {
        background-color: #f8f9fa;
    }
</style>
""", unsafe_allow_html=True)
```

### Step 3: 세션 상태 초기화
```python
# CSS 아래에 추가
if 'prediction_history' not in st.session_state:
    st.session_state.prediction_history = []
if 'api_status' not in st.session_state:
    st.session_state.api_status = False
if 'last_refresh' not in st.session_state:
    st.session_state.last_refresh = datetime.now()
```

### Step 4: 캐싱 함수 추가
```python
# 세션 상태 아래에 추가
@st.cache_data(ttl=60)
def fetch_logs(limit):
    """API에서 로그 가져오기 (캐싱 적용)"""
    try:
        response = requests.get(f"{API_URL}/logs?limit={limit}")
        return response.json() if response.status_code == 200 else []
    except:
        return []

@st.cache_data(ttl=300)
def check_api_status():
    """API 상태 확인 (5분 캐싱)"""
    try:
        response = requests.get(f"{API_URL}/status", timeout=2)
        return response.status_code == 200
    except:
        return False
```

### Step 5: 헤더 및 사이드바 구성
```python
# 타이틀과 상태 표시
col_title, col_status = st.columns([3, 1])
with col_title:
    st.title("✈️ 인천공항 항공편 탑승률 예측 시스템")
    st.markdown("**Advanced ML Dashboard** - 실시간 예측 및 분석 플랫폼")

with col_status:
    api_status = check_api_status()
    if api_status:
        st.success("🟢 시스템 정상")
    else:
        st.error("🔴 시스템 오프라인")

# 사이드바 구성
with st.sidebar:
    st.header("🎛️ 시스템 제어판")
    
    if st.button("🔄 시스템 상태 갱신"):
        st.cache_data.clear()
        st.rerun()
    
    st.divider()
    st.subheader("📊 최근 활동")
    
    recent_logs = fetch_logs(5)
    if recent_logs:
        for log in recent_logs:
            flight = log['flight_number']
            load = log['predicted_load_factor']
            st.info(f"**{flight}**: {load:.1%}")
    else:
        st.info("활동 기록 없음")
```

### Step 6: 탭 구조 설정
```python
# 6개 탭으로 구성
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "🎯 단일 예측", 
    "📦 다중 예측", 
    "📂 CSV 업로드", 
    "📜 히스토리", 
    "📊 분석 대시보드",
    "⚙️ 고급 설정"
])
```

---

## 🎯 Feature 1: 단일 항공편 예측 (Tab 1)

### 목표
기존 단일 예측 기능을 탭 안으로 이동하고, 시각화 강화

### Step 1: 입력 폼 구성
```python
with tab1:
    st.header("🎯 단일 항공편 예측")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        flight_date = st.date_input(
            "운항 날짜",
            value=datetime.now(),
            min_value=datetime.now() - timedelta(days=30),
            max_value=datetime.now() + timedelta(days=90)
        )
        flight_date_int = int(flight_date.strftime("%Y%m%d"))
    
    with col2:
        flight_time = st.time_input(
            "운항 시간",
            value=time(14, 30),
            step=1800  # 30분 단위
        )
        flight_time_int = int(flight_time.strftime("%H%M"))
    
    with col3:
        # 자주 사용하는 항공편 목록 (selectbox로 변경)
        common_flights = ['KE001', 'OZ101', 'LJ263', 'TW234', 'JE567', '7C001']
        flight_number = st.selectbox(
            "항공편명",
            options=common_flights + ['직접 입력'],
            index=0
        )
        
        if flight_number == '직접 입력':
            flight_number = st.text_input("항공편명 입력", "")
```

### Step 2: 예측 실행 및 결과 표시
```python
    # 예측 버튼 (중앙 정렬)
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        predict_button = st.button(
            "🔮 예측 실행",
            use_container_width=True,
            type="primary"
        )
    
    if predict_button and flight_number and flight_number != '직접 입력':
        with st.spinner("AI 모델 예측 중..."):
            try:
                request_data = {
                    "arcft_flt_schd_ymd": flight_date_int,
                    "arcft_flt_schd_hm": flight_time_int,
                    "flt_fltnm": flight_number
                }
                
                response = requests.post(
                    f"{API_URL}/predict",
                    json=request_data,
                    timeout=10
                )
                
                if response.status_code == 200:
                    result = response.json()
                    load_factor = result["predicted_load_factor"]
                    
                    # 세션 히스토리에 추가
                    st.session_state.prediction_history.append({
                        'timestamp': datetime.now(),
                        'flight': flight_number,
                        'date': flight_date,
                        'time': flight_time,
                        'load_factor': load_factor
                    })
                    
                    st.success("✅ 예측 완료!")
                    
                    # 메트릭 카드 (4열)
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric(
                            "항공편",
                            flight_number,
                            f"{flight_date.strftime('%m/%d')}"
                        )
                    
                    with col2:
                        st.metric(
                            "예상 탑승률",
                            f"{load_factor:.1%}",
                            f"{(load_factor - 0.75)*100:.1f}%p" if load_factor > 0.75 else None
                        )
                    
                    with col3:
                        level = "🔴 매우 높음" if load_factor > 0.9 else "🟠 높음" if load_factor > 0.75 else "🟡 보통" if load_factor > 0.5 else "🟢 낮음"
                        st.metric("수준", level)
                    
                    with col4:
                        seats = 300  # 가정
                        expected = int(seats * load_factor)
                        st.metric("예상 승객", f"{expected}명", f"/{seats}석")
```

### Step 3: Gauge 차트 추가
```python
                    # 시각화 (2열)
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        # Gauge chart
                        fig = go.Figure(go.Indicator(
                            mode="gauge+number",
                            value=load_factor * 100,
                            title={'text': "탑승률 (%)"},
                            domain={'x': [0, 1], 'y': [0, 1]},
                            gauge={
                                'axis': {'range': [None, 100]},
                                'bar': {'color': "darkblue"},
                                'steps': [
                                    {'range': [0, 50], 'color': "lightgray"},
                                    {'range': [50, 75], 'color': "yellow"},
                                    {'range': [75, 90], 'color': "orange"},
                                    {'range': [90, 100], 'color': "red"}
                                ],
                                'threshold': {
                                    'line': {'color': "red", 'width': 4},
                                    'thickness': 0.75,
                                    'value': 90
                                }
                            }
                        ))
                        fig.update_layout(height=300)
                        st.plotly_chart(fig, use_container_width=True)
                    
                    with col2:
                        # 세션 히스토리 차트
                        if len(st.session_state.prediction_history) > 1:
                            history_df = pd.DataFrame(st.session_state.prediction_history)
                            fig = px.line(
                                history_df,
                                x='timestamp',
                                y='load_factor',
                                title='세션 내 예측 추이',
                                markers=True
                            )
                            fig.update_yaxis(tickformat='.0%')
                            fig.update_layout(height=300)
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.info("추가 예측을 실행하면 추이를 볼 수 있습니다.")
                
                else:
                    st.error(f"예측 실패: {response.status_code}")
                    
            except requests.exceptions.Timeout:
                st.error("⏱️ 요청 시간 초과")
            except Exception as e:
                st.error(f"❌ 오류: {str(e)}")
```

### 💡 힌트
- `go.Indicator`로 Gauge 차트 생성
- `st.session_state`로 세션 내 예측 기록 관리
- `st.metric`의 delta 파라미터로 변화량 표시

---

## 🎯 Feature 2: 여러 항공편 동시 예측 (Tab 2)

### 목표
한 번에 여러 항공편의 탑승률을 예측하고 결과를 표와 차트로 표시

### Step 1: 동적 입력 폼 (3열 레이아웃)
```python
with tab2:
    st.header("📦 여러 항공편 동시 예측")
    
    # 예측 모드 선택
    col1, col2 = st.columns([2, 1])
    with col1:
        num_flights = st.slider("예측할 항공편 수", 2, 10, 3)
    with col2:
        batch_date = st.date_input("기준 날짜", key="batch_date")
    
    # 동적 입력 폼 (3열 구성)
    flights_data = []
    cols = st.columns(3)
    
    for i in range(num_flights):
        with cols[i % 3]:  # 3열로 순환 배치
            st.subheader(f"✈️ 항공편 {i+1}")
            
            time_input = st.time_input(
                f"시간",
                key=f"batch_time_{i}",
                value=time(8 + i*2, 0)  # 2시간 간격 기본값
            )
            
            flight = st.text_input(
                f"편명",
                key=f"batch_flight_{i}",
                value=f"KE{101 + i}"
            )
            
            flights_data.append({
                "date": batch_date,
                "time": time_input,
                "flight": flight
            })
```

### Step 2: 배치 예측 실행
```python
    # 배치 예측 실행
    if st.button("🚀 모두 예측하기", key="batch_predict", type="primary"):
        # 요청 데이터 준비
        batch_request = {
            "flights": [
                {
                    "arcft_flt_schd_ymd": int(f["date"].strftime("%Y%m%d")),
                    "arcft_flt_schd_hm": int(f["time"].strftime("%H%M")),
                    "flt_fltnm": f["flight"]
                }
                for f in flights_data if f["flight"]  # 빈 항공편 제외
            ]
        }
        
        with st.spinner(f"{len(batch_request['flights'])}개 항공편 예측 중..."):
            try:
                response = requests.post(
                    f"{API_URL}/predict/batch",
                    json=batch_request,
                    timeout=30
                )
                
                if response.status_code == 200:
                    results = response.json()
                    
                    # 결과 DataFrame 생성
                    results_data = []
                    for i, pred in enumerate(results["predictions"]):
                        load = pred['predicted_load_factor']
                        results_data.append({
                            "항공편": flights_data[i]["flight"],
                            "시간": flights_data[i]["time"].strftime("%H:%M"),
                            "예상 탑승률": load,
                            "탑승률(%)": f"{load:.1%}",
                            "수준": "🔴 높음" if load > 0.8 else "🟡 보통" if load > 0.6 else "🟢 낮음"
                        })
                    
                    df_results = pd.DataFrame(results_data)
                    
                    st.success(f"✅ {len(results_data)}개 항공편 예측 완료!")
                    
                    # 요약 통계 (4열)
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("평균 탑승률", f"{df_results['예상 탑승률'].mean():.1%}")
                    with col2:
                        high_count = (df_results['예상 탑승률'] > 0.8).sum()
                        st.metric("고탑승률 항공편", f"{high_count}개")
                    with col3:
                        max_load = df_results['예상 탑승률'].max()
                        st.metric("최고 탑승률", f"{max_load:.1%}")
                    with col4:
                        min_load = df_results['예상 탑승률'].min()
                        st.metric("최저 탑승률", f"{min_load:.1%}")
                    
                    # 결과 테이블
                    st.dataframe(
                        df_results[['항공편', '시간', '탑승률(%)', '수준']],
                        use_container_width=True,
                        hide_index=True
                    )
                    
                    # 막대 차트
                    fig = px.bar(
                        df_results,
                        x='항공편',
                        y='예상 탑승률',
                        color='예상 탑승률',
                        color_continuous_scale='RdYlGn_r',
                        title='항공편별 예상 탑승률'
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # 다운로드
                    csv = df_results.to_csv(index=False, encoding='utf-8-sig')
                    st.download_button(
                        "📥 결과 다운로드 (CSV)",
                        csv,
                        f"batch_predictions_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
                        "text/csv"
                    )
                    
            except Exception as e:
                st.error(f"배치 예측 실패: {str(e)}")
```

### 💡 힌트
- `cols[i % 3]`으로 3열 순환 배치
- `key` 파라미터로 위젯 충돌 방지
- `color_continuous_scale='RdYlGn_r'`로 빨강-노랑-초록 역순 색상

---

## 🎯 Feature 3: CSV 파일 업로드 예측 (Tab 3)

### 목표
CSV 파일을 업로드하여 대량의 항공편 예측 실행

### Step 1: 샘플 CSV 생성기
```python
with tab3:
    st.header("📂 CSV 파일 업로드 예측")
    
    # 샘플 데이터 생성기
    with st.expander("📝 샘플 CSV 생성기"):
        col1, col2, col3 = st.columns(3)
        with col1:
            sample_date = st.date_input("샘플 날짜", key="sample_date")
        with col2:
            sample_count = st.number_input("샘플 수", 5, 50, 10)
        with col3:
            if st.button("📥 샘플 생성"):
                sample_data = pd.DataFrame({
                    'arcft_flt_schd_ymd': [int(sample_date.strftime("%Y%m%d"))] * sample_count,
                    'arcft_flt_schd_hm': [800 + i*100 for i in range(sample_count)],
                    'flt_fltnm': [f'KE{1001+i}' if i % 2 == 0 else f'OZ{2001+i}' for i in range(sample_count)]
                })
                
                csv = sample_data.to_csv(index=False)
                st.download_button(
                    "💾 sample_flights.csv",
                    csv,
                    "sample_flights.csv",
                    "text/csv",
                    key='download_sample_csv'
                )
```

### Step 2: 파일 업로드 및 검증
```python
    # 파일 업로더
    uploaded_file = st.file_uploader(
        "CSV 파일을 선택하세요",
        type=['csv'],
        help="필수 컬럼: arcft_flt_schd_ymd, arcft_flt_schd_hm, flt_fltnm"
    )
    
    if uploaded_file is not None:
        try:
            df_upload = pd.read_csv(uploaded_file)
            
            # 데이터 검증
            required_cols = ['arcft_flt_schd_ymd', 'arcft_flt_schd_hm', 'flt_fltnm']
            missing_cols = [col for col in required_cols if col not in df_upload.columns]
            
            if missing_cols:
                st.error(f"❌ 필수 컬럼 누락: {missing_cols}")
            else:
                # 데이터 미리보기
                st.subheader("📋 데이터 미리보기")
                
                col1, col2, col3 = st.columns([2, 1, 1])
                with col1:
                    st.info(f"📊 총 {len(df_upload)}개 항공편")
                with col2:
                    unique_flights = df_upload['flt_fltnm'].nunique()
                    st.info(f"✈️ {unique_flights}개 고유 항공편")
                with col3:
                    unique_dates = df_upload['arcft_flt_schd_ymd'].nunique()
                    st.info(f"📅 {unique_dates}개 날짜")
                
                st.dataframe(df_upload.head(10), use_container_width=True)
```

### Step 3: 예측 실행
```python
                # 예측 실행 버튼
                if st.button("🚀 CSV 예측 실행", type="primary", key="csv_predict"):
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    batch_data = {
                        "flights": df_upload[required_cols].to_dict('records')
                    }
                    
                    status_text.text(f"🔄 {len(batch_data['flights'])}개 항공편 처리 중...")
                    progress_bar.progress(30)
                    
                    try:
                        response = requests.post(
                            f"{API_URL}/predict/batch",
                            json=batch_data,
                            timeout=60
                        )
                        
                        progress_bar.progress(70)
                        
                        if response.status_code == 200:
                            results = response.json()
                            predictions = results['predictions']
                            
                            # 예측 결과 추가
                            df_upload['predicted_load_factor'] = [p['predicted_load_factor'] for p in predictions]
                            df_upload['load_level'] = df_upload['predicted_load_factor'].apply(
                                lambda x: '높음' if x > 0.8 else '보통' if x > 0.6 else '낮음'
                            )
                            
                            progress_bar.progress(100)
                            status_text.empty()
                            
                            st.success(f"✅ 예측 완료!")
                            
                            # 결과 요약
                            st.subheader("📊 예측 결과 요약")
                            
                            col1, col2, col3, col4 = st.columns(4)
                            with col1:
                                avg_load = df_upload['predicted_load_factor'].mean()
                                st.metric("평균 탑승률", f"{avg_load:.1%}")
                            with col2:
                                std_load = df_upload['predicted_load_factor'].std()
                                st.metric("표준편차", f"{std_load:.1%}")
                            with col3:
                                high_load = (df_upload['predicted_load_factor'] > 0.8).sum()
                                st.metric("고탑승률", f"{high_load}개")
                            with col4:
                                low_load = (df_upload['predicted_load_factor'] < 0.5).sum()
                                st.metric("저탑승률", f"{low_load}개")
```

### Step 4: 결과 시각화 (탭 내 탭)
```python
                            # 시각화 (탭 내부 탭)
                            tab_chart1, tab_chart2, tab_chart3 = st.tabs(["분포도", "시계열", "항공편별"])
                            
                            with tab_chart1:
                                fig = px.histogram(
                                    df_upload,
                                    x='predicted_load_factor',
                                    nbins=30,
                                    title='탑승률 분포'
                                )
                                fig.update_layout(
                                    xaxis_title='예상 탑승률',
                                    xaxis_tickformat='.0%',
                                    yaxis_title='항공편 수'
                                )
                                st.plotly_chart(fig, use_container_width=True)
                            
                            with tab_chart2:
                                if 'arcft_flt_schd_hm' in df_upload.columns:
                                    df_upload['hour'] = df_upload['arcft_flt_schd_hm'] // 100
                                    hourly_avg = df_upload.groupby('hour')['predicted_load_factor'].mean().reset_index()
                                    
                                    fig = px.line(
                                        hourly_avg,
                                        x='hour',
                                        y='predicted_load_factor',
                                        title='시간대별 평균 탑승률',
                                        markers=True
                                    )
                                    fig.update_layout(yaxis_tickformat='.0%')
                                    st.plotly_chart(fig, use_container_width=True)
                            
                            with tab_chart3:
                                top_flights = df_upload.groupby('flt_fltnm')['predicted_load_factor'].mean().nlargest(15).reset_index()
                                
                                fig = px.bar(
                                    top_flights,
                                    x='flt_fltnm',
                                    y='predicted_load_factor',
                                    title='항공편별 평균 탑승률 (Top 15)',
                                    color='predicted_load_factor',
                                    color_continuous_scale='RdYlGn_r'
                                )
                                fig.update_layout(yaxis_tickformat='.0%')
                                st.plotly_chart(fig, use_container_width=True)
                            
                            # 다운로드
                            st.subheader("📥 결과 다운로드")
                            csv_result = df_upload.to_csv(index=False, encoding='utf-8-sig')
                            st.download_button(
                                "📄 CSV 다운로드",
                                csv_result,
                                f"predictions_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
                                "text/csv"
                            )
                            
                    except Exception as e:
                        st.error(f"예측 실패: {str(e)}")
                    finally:
                        progress_bar.empty()
                        status_text.empty()
                        
        except Exception as e:
            st.error(f"파일 읽기 오류: {str(e)}")
```

### 💡 힌트
- `st.expander`로 접을 수 있는 섹션 생성
- `st.progress`와 `st.empty()`로 진행 상황 표시
- `fig.update_layout(yaxis_tickformat='.0%')`로 퍼센트 형식 적용

---

## 🎯 Feature 4: 예측 히스토리 (Tab 4)

### 목표
DB에 저장된 예측 기록을 조회하고 필터링

### Step 1: 조회 옵션 및 검색
```python
with tab4:
    st.header("📜 예측 히스토리")
    
    # 조회 옵션
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        limit = st.selectbox("조회 개수", [10, 20, 50, 100, 200], index=1)
    with col2:
        if st.button("🔄 새로고침", key="refresh_history"):
            st.cache_data.clear()
            st.rerun()
    with col3:
        search_flight = st.text_input("🔍 항공편 검색", placeholder="예: KE001")
```

### Step 2: 데이터 로드 및 표시
```python
    try:
        logs = fetch_logs(limit)  # 캐싱된 함수 사용
        
        if logs:
            df_logs = pd.DataFrame(logs)
            
            # 검색 필터 적용
            if search_flight:
                df_logs = df_logs[df_logs['flight_number'].str.contains(search_flight, case=False)]
            
            # 데이터 포맷팅
            df_logs['날짜'] = pd.to_datetime(df_logs['flight_date'].astype(str), format='%Y%m%d').dt.strftime('%Y-%m-%d')
            df_logs['시간'] = df_logs['flight_time'].apply(lambda x: f"{x//100:02d}:{x%100:02d}")
            df_logs['탑승률'] = df_logs['predicted_load_factor'].apply(lambda x: f"{x:.1%}")
            df_logs['생성시각'] = pd.to_datetime(df_logs['created_at']).dt.strftime('%m/%d %H:%M')
            
            # 통계 요약 (5열)
            st.subheader("📊 통계 요약")
            col1, col2, col3, col4, col5 = st.columns(5)
            
            with col1:
                st.metric("전체 예측", f"{len(df_logs):,}건")
            with col2:
                avg_load = df_logs['predicted_load_factor'].mean()
                st.metric("평균", f"{avg_load:.1%}")
            with col3:
                median_load = df_logs['predicted_load_factor'].median()
                st.metric("중앙값", f"{median_load:.1%}")
            with col4:
                max_load = df_logs['predicted_load_factor'].max()
                st.metric("최고", f"{max_load:.1%}")
            with col5:
                min_load = df_logs['predicted_load_factor'].min()
                st.metric("최저", f"{min_load:.1%}")
```

### Step 3: 고급 필터
```python
            # 고급 필터
            with st.expander("🔍 고급 필터"):
                col1, col2 = st.columns(2)
                
                with col1:
                    unique_flights = sorted(df_logs['flight_number'].unique())
                    selected_flights = st.multiselect(
                        "항공편 선택",
                        unique_flights,
                        default=[]
                    )
                
                with col2:
                    date_range = st.date_input(
                        "날짜 범위",
                        value=[],
                        key="date_range_filter"
                    )
                
                # 필터 적용
                filtered_df = df_logs.copy()
                
                # 데이터 표시
                st.subheader(f"📋 예측 기록 ({len(filtered_df)}건)")
                
                display_df = filtered_df[['flight_number', '날짜', '시간', '탑승률', '생성시각']].rename(columns={
                    'flight_number': '항공편'
                })
                
                st.dataframe(
                    display_df,
                    use_container_width=True,
                    hide_index=True,
                    height=400
                )
        else:
            st.info("아직 예측 기록이 없습니다.")
    
    except Exception as e:
        st.error(f"히스토리 조회 실패: {str(e)}")
```

### 💡 힌트
- `@st.cache_data(ttl=60)`로 60초 캐싱
- `st.rerun()`으로 페이지 새로고침
- `st.multiselect`로 다중 선택 필터

---

## 🎯 Feature 5: 분석 대시보드 (Tab 5)

### 목표
종합적인 데이터 분석 및 시각화

### Step 1: 데이터 준비
```python
with tab5:
    st.header("📊 종합 분석 대시보드")
    
    try:
        logs = fetch_logs(200)
        
        if logs:
            df = pd.DataFrame(logs)
            df['hour'] = df['flight_time'] // 100
            df['date'] = pd.to_datetime(df['flight_date'].astype(str), format='%Y%m%d')
            df['weekday'] = df['date'].dt.day_name()
            df['week'] = df['date'].dt.isocalendar().week
```

### Step 2: 시간대별 분석
```python
            col1, col2 = st.columns(2)
            
            with col1:
                # 시간대별 평균 탑승률 (표준편차 포함)
                hourly_avg = df.groupby('hour')['predicted_load_factor'].agg(['mean', 'std', 'count']).reset_index()
                
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=hourly_avg['hour'],
                    y=hourly_avg['mean'],
                    mode='lines+markers',
                    name='평균 탑승률',
                    line=dict(width=3),
                    marker=dict(size=8)
                ))
                
                # 표준편차 영역 추가
                fig.add_trace(go.Scatter(
                    x=hourly_avg['hour'].tolist() + hourly_avg['hour'].tolist()[::-1],
                    y=(hourly_avg['mean'] + hourly_avg['std']).tolist() + 
                      (hourly_avg['mean'] - hourly_avg['std']).tolist()[::-1],
                    fill='toself',
                    fillcolor='rgba(0,100,200,0.2)',
                    line=dict(color='rgba(255,255,255,0)'),
                    name='±1 표준편차'
                ))
                
                fig.update_layout(
                    title='시간대별 평균 탑승률',
                    xaxis_title='시간',
                    yaxis_title='탑승률',
                    yaxis_tickformat='.0%',
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
```

### Step 3: 히트맵 차트
```python
            with col2:
                # 요일별/시간별 히트맵
                heatmap_data = df.pivot_table(
                    values='predicted_load_factor',
                    index='hour',
                    columns='weekday',
                    aggfunc='mean'
                )
                
                # 요일 순서 정렬
                day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                heatmap_data = heatmap_data.reindex(columns=[d for d in day_order if d in heatmap_data.columns])
                
                fig = go.Figure(data=go.Heatmap(
                    z=heatmap_data.values,
                    x=heatmap_data.columns,
                    y=heatmap_data.index,
                    colorscale='RdYlGn_r',
                    text=heatmap_data.values,
                    texttemplate='%{text:.0%}',
                    textfont={"size": 10},
                    colorbar=dict(title="탑승률", tickformat='.0%')
                ))
                
                fig.update_layout(
                    title="요일별/시간별 평균 탑승률",
                    xaxis_title="요일",
                    yaxis_title="시간",
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
```

### Step 4: 항공편별 분석
```python
            st.subheader("✈️ 항공편별 상세 분석")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Top 10 항공편
                top_flights = df.groupby('flight_number')['predicted_load_factor'].agg(['mean', 'count']).nlargest(10, 'mean').reset_index()
                
                fig = px.bar(
                    top_flights,
                    x='flight_number',
                    y='mean',
                    title='탑승률 Top 10 항공편',
                    labels={'mean': '평균 탑승률', 'flight_number': '항공편'},
                    color='mean',
                    color_continuous_scale='RdYlGn_r',
                    text='mean'
                )
                fig.update_traces(texttemplate='%{text:.1%}', textposition='outside')
                fig.update_layout(yaxis_tickformat='.0%', height=400)
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # 탑승률 분포 박스플롯
                top_flight_list = top_flights['flight_number'].tolist()
                df_top = df[df['flight_number'].isin(top_flight_list)]
                
                fig = px.box(
                    df_top,
                    x='flight_number',
                    y='predicted_load_factor',
                    title='항공편별 탑승률 분포',
                    labels={'predicted_load_factor': '탑승률', 'flight_number': '항공편'}
                )
                fig.update_layout(yaxis_tickformat='.0%', height=400)
                st.plotly_chart(fig, use_container_width=True)
```

### Step 5: 시계열 트렌드
```python
            st.subheader("📈 시계열 트렌드")
            
            # 일별 집계
            daily_stats = df.groupby(df['date'].dt.date)['predicted_load_factor'].agg(['mean', 'min', 'max', 'count']).reset_index()
            
            fig = go.Figure()
            
            # 평균선
            fig.add_trace(go.Scatter(
                x=daily_stats['date'],
                y=daily_stats['mean'],
                mode='lines+markers',
                name='평균',
                line=dict(width=3, color='blue')
            ))
            
            # 최대/최소 범위
            fig.add_trace(go.Scatter(
                x=daily_stats['date'],
                y=daily_stats['max'],
                mode='lines',
                name='최대',
                line=dict(width=1, dash='dot', color='red')
            ))
            
            fig.add_trace(go.Scatter(
                x=daily_stats['date'],
                y=daily_stats['min'],
                mode='lines',
                name='최소',
                line=dict(width=1, dash='dot', color='green')
            ))
            
            fig.update_layout(
                title='일별 탑승률 추이',
                xaxis_title='날짜',
                yaxis_title='탑승률',
                yaxis_tickformat='.0%',
                height=400,
                hovermode='x unified'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
        else:
            st.info("분석할 데이터가 없습니다. 예측을 먼저 실행해주세요.")
            
    except Exception as e:
        st.error(f"분석 데이터 로드 실패: {str(e)}")
```

### 💡 힌트
- `go.Heatmap`으로 히트맵 생성
- `px.box`로 박스플롯 생성
- `hovermode='x unified'`로 통합 호버 표시

---

## 🎯 Feature 6: 고급 설정 (Tab 6)

### 목표
API 설정 및 세션 정보 관리

```python
with tab6:
    st.header("⚙️ 고급 설정 및 정보")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🔧 API 설정")
        
        custom_api = st.text_input(
            "API 서버 주소",
            value=API_URL,
            help="기본값: http://localhost:8000"
        )
        
        if st.button("API 변경 적용"):
            API_URL = custom_api
            st.success("API 주소가 변경되었습니다.")
            st.cache_data.clear()
        
        if st.button("API 상태 상세 조회"):
            try:
                response = requests.get(f"{API_URL}/status")
                if response.status_code == 200:
                    st.json(response.json())
            except Exception as e:
                st.error(f"상태 조회 실패: {str(e)}")
    
    with col2:
        st.subheader("📊 세션 정보")
        
        if st.session_state.prediction_history:
            session_df = pd.DataFrame(st.session_state.prediction_history)
            
            st.metric("세션 내 예측 수", len(session_df))
            st.metric("평균 탑승률", f"{session_df['load_factor'].mean():.1%}")
            
            if st.button("세션 초기화", type="secondary"):
                st.session_state.prediction_history = []
                st.success("세션 히스토리가 초기화되었습니다.")
                st.rerun()
        else:
            st.info("세션 내 예측 기록이 없습니다.")
    
    # 시스템 정보
    st.divider()
    st.subheader("ℹ️ 시스템 정보")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.info(f"""
        **버전 정보**
        - Streamlit: {st.__version__}
        - API: v1.0
        - 모델: Random Forest
        """)
    
    with col2:
        st.info(f"""
        **캐시 설정**
        - 로그 캐시: 60초
        - API 상태: 300초
        - 마지막 갱신: {st.session_state.last_refresh.strftime('%H:%M:%S')}
        """)
    
    with col3:
        st.info(f"""
        **제한 사항**
        - 최대 배치: 100개
        - 타임아웃: 60초
        - 최대 로그: 1000개
        """)
```

---

## 🎨 마무리: Footer 추가

```python
# 파일 맨 아래에 추가
st.divider()
st.markdown("""
<div style='text-align: center; color: gray;'>
    <p>ML Systems Design 클래스 - Advanced Dashboard v2.0</p>
    <p>멘토: 김승원 | 인천국제공항공사 운영DX팀</p>
</div>
""", unsafe_allow_html=True)
```

---

## 🚨 주의사항

1. **API 서버 실행 중인지 확인**
2. **포트 번호 일치 확인** (기본: 8000)
3. **대용량 데이터는 배치 크기 조절**
4. **세션 상태는 새로고침시 초기화**
5. **차트가 많으면 로딩 속도 저하**

---

## 📚 참고 자료

- [Streamlit 공식 문서](https://docs.streamlit.io)
- [Plotly Python](https://plotly.com/python/)
- [Plotly Graph Objects](https://plotly.com/python/graph-objects/)
- [Pandas 문서](https://pandas.pydata.org/docs/)
- [FastAPI 문서](https://fastapi.tiangolo.com)

---

**다음 세션**: Docker 컨테이너화 및 배포
**문의**: 김승원 멘토
