# Streamlit 핵심 개념 실습 가이드
## 🎯 app_simple.py에 핵심 기능 추가하기

### 📌 학습 목표
1. **세션 상태 관리** - 페이지 새로고침에도 데이터 유지
2. **캐싱 활용** - API 호출 최적화
3. **대시보드 레이아웃** - 탭과 컬럼 활용
4. **데이터 시각화** - Plotly 차트 추가

---

## 📚 개념 1: 세션 상태 관리 (Session State)

### 왜 필요한가?
Streamlit은 사용자 인터랙션마다 전체 스크립트를 다시 실행합니다. 
일반 변수는 매번 초기화되지만, `st.session_state`는 유지됩니다.

### 실습: 예측 히스토리 저장하기

**① 파일 상단에 추가** (import 아래)
```python
# ============ 세션 상태 초기화 ============
if 'prediction_history' not in st.session_state:
    st.session_state.prediction_history = []
```

**② 예측 성공 후 저장** (`st.success("✅ 예측 완료!")` 아래에 추가)
```python
# 세션에 예측 결과 저장
st.session_state.prediction_history.append({
    'flight': flight_number,
    'load_factor': load_factor,
    'timestamp': datetime.now().strftime("%H:%M:%S")
})
```

**③ 히스토리 표시** (예측 결과 표시 아래에 추가)
```python
# 세션 내 예측 기록 표시
if st.session_state.prediction_history:
    st.divider()
    st.subheader("📝 이번 세션 예측 기록")
    for i, record in enumerate(st.session_state.prediction_history[-5:], 1):
        st.write(f"{i}. **{record['flight']}**: {record['load_factor']:.1%} ({record['timestamp']})")
```

### 💡 핵심 포인트
- `st.session_state`는 딕셔너리처럼 사용
- 초기화는 `if 'key' not in st.session_state:` 패턴 사용
- 브라우저 새로고침 전까지 데이터 유지

---

## 📚 개념 2: 캐싱 활용 (@st.cache_data)

### 왜 필요한가?
동일한 API 호출을 반복하면 서버 부하가 증가합니다.
캐싱을 사용하면 일정 시간 동안 결과를 재사용합니다.

### 실습: API 상태 체크 캐싱

**① import 아래에 캐싱 함수 추가**
```python
# ============ 캐싱 함수 ============
@st.cache_data(ttl=60)  # 60초 동안 캐시 유지
def check_api_status():
    """API 상태 확인 (캐싱 적용)"""
    try:
        response = requests.get(f"{API_URL}/status", timeout=2)
        return response.status_code == 200
    except:
        return False

@st.cache_data(ttl=30)  # 30초 동안 캐시 유지
def fetch_logs(limit):
    """로그 조회 (캐싱 적용)"""
    try:
        response = requests.get(f"{API_URL}/logs?limit={limit}")
        return response.json() if response.status_code == 200 else []
    except:
        return []
```

**② 사이드바 API 체크 수정**
```python
# 기존 버튼 방식 대신 자동 체크
st.sidebar.header("🔌 API 서버 상태")
if check_api_status():
    st.sidebar.success("✅ 정상 작동")
else:
    st.sidebar.error("❌ 연결 실패")

# 캐시 초기화 버튼
if st.sidebar.button("🔄 상태 갱신"):
    st.cache_data.clear()
    st.rerun()
```

### 💡 핵심 포인트
- `@st.cache_data(ttl=초)` - 지정된 시간 동안 결과 캐싱
- `st.cache_data.clear()` - 모든 캐시 초기화
- API 호출, DB 조회 등 비용이 큰 작업에 적용

---

## 📚 개념 3: 대시보드 레이아웃 (탭 & 컬럼)

### 왜 필요한가?
복잡한 기능을 논리적으로 분리하고, 화면을 효율적으로 활용합니다.

### 실습: 탭으로 기능 분리

**① 페이지 설정 변경**
```python
st.set_page_config(
    page_title="✈️ 항공편 탑승률 예측",
    page_icon="✈️",
    layout="wide"  # centered → wide 변경
)
```

**② 탭 구조로 변경** (기존 코드를 탭 안으로 이동)
```python
# 탭 생성
tab1, tab2 = st.tabs(["🎯 예측하기", "📜 히스토리"])

# Tab 1: 예측 기능
with tab1:
    st.header("📝 항공편 정보 입력")
    
    # 기존 입력 폼 코드...
    col1, col2 = st.columns(2)
    # ... (기존 코드 그대로)

# Tab 2: 히스토리
with tab2:
    st.header("📜 예측 히스토리")
    
    limit = st.selectbox("조회 개수", [10, 20, 50], index=0)
    
    logs = fetch_logs(limit)  # 캐싱된 함수 사용
    
    if logs:
        df = pd.DataFrame(logs)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        # 간단한 통계
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("총 예측 수", len(df))
        with col2:
            st.metric("평균 탑승률", f"{df['predicted_load_factor'].mean():.1%}")
        with col3:
            st.metric("최고 탑승률", f"{df['predicted_load_factor'].max():.1%}")
    else:
        st.info("예측 기록이 없습니다.")
```

### 💡 핵심 포인트
- `st.tabs()` - 탭 생성, `with tab:` 로 내용 배치
- `st.columns()` - 가로 분할, 숫자 또는 비율 리스트 가능
- `layout="wide"` - 화면 전체 너비 사용

---

## 📚 개념 4: 데이터 시각화 (Plotly)

### 왜 필요한가?
숫자만으로는 데이터 패턴을 파악하기 어렵습니다.
인터랙티브 차트로 직관적인 분석이 가능합니다.

### 실습: Plotly 차트 추가

**① import 추가**
```python
import plotly.express as px
import plotly.graph_objects as go
```

**② 예측 결과에 Gauge 차트 추가** (메트릭 표시 아래)
```python
# Gauge 차트로 시각화
fig = go.Figure(go.Indicator(
    mode="gauge+number",
    value=load_factor * 100,
    title={'text': "탑승률 (%)"},
    gauge={
        'axis': {'range': [0, 100]},
        'bar': {'color': "darkblue"},
        'steps': [
            {'range': [0, 50], 'color': "lightgreen"},
            {'range': [50, 80], 'color': "yellow"},
            {'range': [80, 100], 'color': "salmon"}
        ]
    }
))
fig.update_layout(height=300)
st.plotly_chart(fig, use_container_width=True)
```

**③ 히스토리 탭에 차트 추가**
```python
# Tab 2 내부, 데이터프레임 표시 후
if logs and len(df) > 1:
    st.subheader("📊 탑승률 분포")
    
    # 히스토그램
    fig = px.histogram(
        df, 
        x='predicted_load_factor',
        nbins=20,
        title='예측 탑승률 분포'
    )
    fig.update_layout(
        xaxis_title='탑승률',
        yaxis_title='빈도',
        xaxis_tickformat='.0%'
    )
    st.plotly_chart(fig, use_container_width=True)
```

### 💡 핵심 포인트
- `plotly.express (px)` - 빠른 차트 생성
- `plotly.graph_objects (go)` - 세밀한 커스터마이징
- `st.plotly_chart()` - Streamlit에 차트 표시
- `use_container_width=True` - 컨테이너 너비에 맞춤

---

## 🔧 전체 적용 코드 (최소 버전)

```python
import streamlit as st
import requests
import pandas as pd
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go

# ============ 페이지 설정 ============
st.set_page_config(
    page_title="✈️ 항공편 탑승률 예측",
    page_icon="✈️",
    layout="wide"
)

# ============ 세션 상태 초기화 ============
if 'prediction_history' not in st.session_state:
    st.session_state.prediction_history = []

# ============ 캐싱 함수 ============
API_URL = "http://localhost:8000"

@st.cache_data(ttl=60)
def check_api_status():
    try:
        response = requests.get(f"{API_URL}/status", timeout=2)
        return response.status_code == 200
    except:
        return False

@st.cache_data(ttl=30)
def fetch_logs(limit):
    try:
        response = requests.get(f"{API_URL}/logs?limit={limit}")
        return response.json() if response.status_code == 200 else []
    except:
        return []

# ============ 사이드바 ============
st.sidebar.header("🔌 시스템 상태")
if check_api_status():
    st.sidebar.success("✅ API 정상")
else:
    st.sidebar.error("❌ API 오프라인")

if st.sidebar.button("🔄 새로고침"):
    st.cache_data.clear()
    st.rerun()

# ============ 메인 ============
st.title("✈️ 항공편 탑승률 예측 시스템")

tab1, tab2 = st.tabs(["🎯 예측하기", "📜 히스토리"])

# ============ Tab 1: 예측 ============
with tab1:
    col1, col2, col3 = st.columns(3)
    
    with col1:
        flight_date = st.date_input("운항 날짜")
    with col2:
        flight_time = st.time_input("운항 시간")
    with col3:
        flight_number = st.text_input("항공편명", "KE001")
    
    if st.button("🔮 예측하기", type="primary"):
        request_data = {
            "arcft_flt_schd_ymd": int(flight_date.strftime("%Y%m%d")),
            "arcft_flt_schd_hm": int(flight_time.strftime("%H%M")),
            "flt_fltnm": flight_number
        }
        
        with st.spinner("예측 중..."):
            try:
                response = requests.post(f"{API_URL}/predict", json=request_data)
                
                if response.status_code == 200:
                    result = response.json()
                    load_factor = result["predicted_load_factor"]
                    
                    # 세션에 저장
                    st.session_state.prediction_history.append({
                        'flight': flight_number,
                        'load_factor': load_factor,
                        'time': datetime.now().strftime("%H:%M")
                    })
                    
                    st.success("✅ 예측 완료!")
                    
                    # 메트릭
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("항공편", flight_number)
                    with col2:
                        st.metric("예상 탑승률", f"{load_factor:.1%}")
                    
                    # Gauge 차트
                    fig = go.Figure(go.Indicator(
                        mode="gauge+number",
                        value=load_factor * 100,
                        title={'text': "탑승률 (%)"},
                        gauge={
                            'axis': {'range': [0, 100]},
                            'steps': [
                                {'range': [0, 50], 'color': "lightgreen"},
                                {'range': [50, 80], 'color': "yellow"},
                                {'range': [80, 100], 'color': "salmon"}
                            ]
                        }
                    ))
                    fig.update_layout(height=300)
                    st.plotly_chart(fig, use_container_width=True)
                    
            except Exception as e:
                st.error(f"오류: {str(e)}")
    
    # 세션 히스토리 표시
    if st.session_state.prediction_history:
        st.divider()
        st.subheader("📝 이번 세션 기록")
        for r in st.session_state.prediction_history[-5:]:
            st.write(f"• **{r['flight']}**: {r['load_factor']:.1%} ({r['time']})")

# ============ Tab 2: 히스토리 ============
with tab2:
    limit = st.selectbox("조회 개수", [10, 20, 50])
    logs = fetch_logs(limit)
    
    if logs:
        df = pd.DataFrame(logs)
        
        col1, col2, col3 = st.columns(3)
        col1.metric("총 예측", len(df))
        col2.metric("평균", f"{df['predicted_load_factor'].mean():.1%}")
        col3.metric("최고", f"{df['predicted_load_factor'].max():.1%}")
        
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        if len(df) > 1:
            fig = px.histogram(df, x='predicted_load_factor', nbins=15)
            fig.update_layout(xaxis_tickformat='.0%')
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("기록이 없습니다.")
```

---

## 📋 학습 체크리스트

| 개념 | 핵심 코드 | 확인 |
|------|----------|------|
| 세션 상태 | `st.session_state['key']` | ☐ |
| 캐싱 | `@st.cache_data(ttl=60)` | ☐ |
| 탭 레이아웃 | `st.tabs()`, `with tab:` | ☐ |
| 컬럼 레이아웃 | `st.columns()` | ☐ |
| Plotly 차트 | `st.plotly_chart()` | ☐ |
| 메트릭 표시 | `st.metric()` | ☐ |

---

## 🚀 추가 도전 과제

1. **세션 초기화 버튼** 추가해보기
2. **탭 3개**로 확장 (분석 탭 추가)
3. **시간대별 막대 차트** 만들어보기
4. **CSV 다운로드** 기능 추가해보기

---

**💡 Tip**: 각 개념을 하나씩 추가하면서 `streamlit run app.py`로 확인하세요!
