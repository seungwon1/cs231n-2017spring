# Streamlit 기능 확장 가이드
## 🚀 기본 예측 페이지에서 고급 기능 추가하기

### 📌 시작하기 전에
- 기본 `app_simple.py`가 정상 작동해야 합니다
- 각 기능을 하나씩 추가하면서 테스트하세요
- 코드 백업을 권장합니다: `cp app_simple.py app_simple_backup.py`

---

## 🎯 Feature 1: 여러 항공편 동시 예측

### 목표
한 번에 여러 항공편의 탑승률을 예측하고 결과를 표로 표시

### Step 1: UI에 다중 입력 추가
```python
# app_simple.py의 예측 입력 폼 아래에 추가

st.divider()
st.header("📦 여러 항공편 동시 예측")

# 동시 예측 모드 선택
multi_mode = st.checkbox("여러 항공편 동시 예측 모드")

if multi_mode:
    # 항공편 개수 선택
    num_flights = st.slider("예측할 항공편 수", 2, 5, 3)
    
    # 동적으로 입력 폼 생성
    flights_data = []
    
    for i in range(num_flights):
        st.subheader(f"항공편 {i+1}")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            date = st.date_input(
                f"날짜 {i+1}",
                key=f"date_{i}",  # 고유한 key 필요!
                value=datetime(2025, 11, 24)
            )
        
        with col2:
            time_input = st.time_input(
                f"시간 {i+1}",
                key=f"time_{i}",
                value=time(14, 30)
            )
        
        with col3:
            flight = st.text_input(
                f"항공편명 {i+1}",
                key=f"flight_{i}",
                value=f"KE00{i+1}"
            )
        
        # 데이터 저장
        flights_data.append({
            "date": date,
            "time": time_input,
            "flight": flight
        })
    
    # 일괄 예측 버튼
    if st.button("🚀 모두 예측하기", key="multi_predict"):
        # 예측 실행 코드는 Step 2에서
        pass
```

### Step 2: 배치 API 호출 구현
```python
# 일괄 예측 버튼 내부 로직
if st.button("🚀 모두 예측하기", key="multi_predict"):
    # API 요청 데이터 준비
    batch_request = {
        "flights": []
    }
    
    for flight_info in flights_data:
        batch_request["flights"].append({
            "arcft_flt_schd_ymd": int(flight_info["date"].strftime("%Y%m%d")),
            "arcft_flt_schd_hm": int(flight_info["time"].strftime("%H%M")),
            "flt_fltnm": flight_info["flight"]
        })
    
    # API 호출
    with st.spinner("여러 항공편 예측 중..."):
        try:
            response = requests.post(
                f"{API_URL}/predict/batch",
                json=batch_request
            )
            
            if response.status_code == 200:
                results = response.json()
                
                # 결과를 DataFrame으로 변환
                results_data = []
                for i, pred in enumerate(results["predictions"]):
                    results_data.append({
                        "항공편": flights_data[i]["flight"],
                        "날짜": flights_data[i]["date"].strftime("%Y-%m-%d"),
                        "시간": flights_data[i]["time"].strftime("%H:%M"),
                        "예상 탑승률": f"{pred['predicted_load_factor']:.1%}",
                        "탑승률 수준": "높음" if pred['predicted_load_factor'] > 0.8 else "보통" if pred['predicted_load_factor'] > 0.6 else "낮음"
                    })
                
                # 표로 표시
                st.success("✅ 모든 예측 완료!")
                df_results = pd.DataFrame(results_data)
                st.dataframe(df_results, use_container_width=True)
                
                # CSV 다운로드 버튼
                csv = df_results.to_csv(index=False, encoding='utf-8-sig')
                st.download_button(
                    "📥 결과 다운로드 (CSV)",
                    csv,
                    "predictions.csv",
                    "text/csv",
                    key='download-csv'
                )
                
        except Exception as e:
            st.error(f"오류 발생: {str(e)}")
```

### 💡 힌트
- `key` 파라미터를 사용해 위젯 충돌 방지
- DataFrame으로 변환하면 표 형식으로 깔끔하게 표시
- `encoding='utf-8-sig'`로 한글 깨짐 방지

---

## 🎯 Feature 2: 예측 히스토리 표시

### 목표
DB에 저장된 예측 기록을 조회하고 표시

### Step 1: 히스토리 탭 추가
```python
# 파일 상단에 탭 추가
tab1, tab2, tab3 = st.tabs(["🎯 예측하기", "📜 히스토리", "📊 분석"])

# 기존 예측 코드를 tab1 안으로 이동
with tab1:
    # 기존 예측 코드들...
    pass

# 새로운 히스토리 탭
with tab2:
    st.header("📜 예측 히스토리")
    # Step 2의 코드가 여기에
```

### Step 2: DB 로그 조회 구현
```python
with tab2:
    st.header("📜 예측 히스토리")
    
    # 조회 옵션
    col1, col2 = st.columns(2)
    with col1:
        limit = st.selectbox(
            "조회 개수",
            [10, 20, 50, 100],
            index=0
        )
    
    with col2:
        if st.button("🔄 새로고침", key="refresh_history"):
            st.rerun()  # 페이지 새로고침
    
    # API에서 로그 가져오기
    try:
        response = requests.get(f"{API_URL}/logs?limit={limit}")
        
        if response.status_code == 200:
            logs = response.json()
            
            if logs:
                # DataFrame 변환
                df_logs = pd.DataFrame(logs)
                
                # 날짜/시간 포맷팅
                df_logs['날짜'] = pd.to_datetime(
                    df_logs['flight_date'].astype(str), 
                    format='%Y%m%d'
                ).dt.strftime('%Y-%m-%d')
                
                df_logs['시간'] = df_logs['flight_time'].apply(
                    lambda x: f"{x//100:02d}:{x%100:02d}"
                )
                
                df_logs['탑승률'] = df_logs['predicted_load_factor'].apply(
                    lambda x: f"{x:.1%}"
                )
                
                df_logs['생성시각'] = pd.to_datetime(
                    df_logs['created_at']
                ).dt.strftime('%Y-%m-%d %H:%M:%S')
                
                # 컬럼 선택 및 이름 변경
                display_df = df_logs[[
                    'flight_number', '날짜', '시간', 
                    '탑승률', '생성시각'
                ]].rename(columns={
                    'flight_number': '항공편'
                })
                
                # 표시
                st.dataframe(
                    display_df,
                    use_container_width=True,
                    hide_index=True
                )
                
                # 통계 표시
                st.divider()
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("전체 예측 수", len(df_logs))
                
                with col2:
                    avg_load = df_logs['predicted_load_factor'].mean()
                    st.metric("평균 탑승률", f"{avg_load:.1%}")
                
                with col3:
                    max_load = df_logs['predicted_load_factor'].max()
                    st.metric("최고 탑승률", f"{max_load:.1%}")
                
                with col4:
                    min_load = df_logs['predicted_load_factor'].min()
                    st.metric("최저 탑승률", f"{min_load:.1%}")
                    
            else:
                st.info("아직 예측 기록이 없습니다.")
                
    except Exception as e:
        st.error(f"히스토리 조회 실패: {str(e)}")
```

### Step 3: 필터링 기능 추가
```python
# 히스토리 탭에 추가
st.subheader("🔍 필터링")

col1, col2, col3 = st.columns(3)

with col1:
    # 특정 항공편 필터
    if logs:
        unique_flights = df_logs['flight_number'].unique()
        selected_flight = st.selectbox(
            "항공편 선택",
            ["전체"] + list(unique_flights)
        )

with col2:
    # 날짜 범위 필터
    date_filter = st.date_input(
        "날짜 선택",
        value=[],  # 빈 값으로 시작
        key="date_filter"
    )

with col3:
    # 탑승률 범위 필터
    load_range = st.slider(
        "탑승률 범위",
        0.0, 1.0, (0.0, 1.0),
        step=0.1,
        format="%.0%%"
    )

# 필터 적용
filtered_df = display_df.copy()

if selected_flight != "전체":
    filtered_df = filtered_df[filtered_df['항공편'] == selected_flight]

if date_filter:
    # 날짜 필터 적용 로직
    pass

# 필터링된 결과 표시
st.dataframe(filtered_df)
```

### 💡 힌트
- `st.rerun()`으로 페이지 새로고침
- pandas DataFrame으로 데이터 조작이 쉬워짐
- `hide_index=True`로 깔끔한 표 표시

---

## 🎯 Feature 3: 차트 추가 (시간대별 탑승률)

### 목표
예측 데이터를 다양한 차트로 시각화

### Step 1: Plotly 임포트 추가
```python
# 파일 상단에 추가
import plotly.express as px
import plotly.graph_objects as go
```

### Step 2: 분석 탭에 차트 추가
```python
with tab3:
    st.header("📊 데이터 분석")
    
    # 데이터 로드
    try:
        response = requests.get(f"{API_URL}/logs?limit=100")
        if response.status_code == 200:
            logs = response.json()
            
            if logs:
                df = pd.DataFrame(logs)
                
                # 시간대별 평균 탑승률
                st.subheader("⏰ 시간대별 평균 탑승률")
                
                # 시간대 그룹화
                df['hour'] = df['flight_time'] // 100
                hourly_avg = df.groupby('hour')['predicted_load_factor'].agg([
                    'mean', 'count', 'std'
                ]).reset_index()
                
                # Line chart
                fig_line = px.line(
                    hourly_avg,
                    x='hour',
                    y='mean',
                    title='시간대별 평균 탑승률',
                    labels={
                        'hour': '시간',
                        'mean': '평균 탑승률'
                    },
                    markers=True
                )
                
                # Y축 포맷을 퍼센트로
                fig_line.update_yaxis(tickformat='.0%')
                
                st.plotly_chart(fig_line, use_container_width=True)
                
                # 항공편별 탑승률 분포
                st.subheader("✈️ 항공편별 탑승률 분포")
                
                # Box plot
                fig_box = px.box(
                    df,
                    x='flight_number',
                    y='predicted_load_factor',
                    title='항공편별 탑승률 분포'
                )
                
                fig_box.update_yaxis(tickformat='.0%')
                st.plotly_chart(fig_box, use_container_width=True)
                
    except Exception as e:
        st.error(f"데이터 로드 실패: {str(e)}")
```

### Step 3: 히트맵 추가
```python
# 분석 탭에 추가
st.subheader("🗓️ 일별/시간별 탑승률 히트맵")

# 데이터 준비
df['date'] = pd.to_datetime(df['flight_date'].astype(str), format='%Y%m%d')
df['weekday'] = df['date'].dt.day_name()
df['hour'] = df['flight_time'] // 100

# 피벗 테이블 생성
heatmap_data = df.pivot_table(
    values='predicted_load_factor',
    index='hour',
    columns='weekday',
    aggfunc='mean'
)

# Heatmap
fig_heat = go.Figure(data=go.Heatmap(
    z=heatmap_data.values,
    x=heatmap_data.columns,
    y=heatmap_data.index,
    colorscale='RdYlGn',
    text=heatmap_data.values,
    texttemplate='%{text:.0%}',
    textfont={"size": 10},
    colorbar=dict(title="탑승률")
))

fig_heat.update_layout(
    title="요일별/시간별 평균 탑승률",
    xaxis_title="요일",
    yaxis_title="시간"
)

st.plotly_chart(fig_heat, use_container_width=True)
```

### Step 4: 실시간 업데이트 차트
```python
# 실시간 모니터링 (자동 새로고침)
st.subheader("📈 실시간 모니터링")

# 자동 새로고침 옵션
auto_refresh = st.checkbox("5초마다 자동 새로고침")

if auto_refresh:
    import time
    time.sleep(5)
    st.rerun()

# 최근 20개 예측 추이
recent_response = requests.get(f"{API_URL}/logs?limit=20")
if recent_response.status_code == 200:
    recent_logs = recent_response.json()
    
    if recent_logs:
        recent_df = pd.DataFrame(recent_logs)
        recent_df['timestamp'] = pd.to_datetime(recent_df['created_at'])
        
        # 시계열 차트
        fig_time = px.line(
            recent_df,
            x='timestamp',
            y='predicted_load_factor',
            title='최근 예측 추이',
            markers=True,
            text='flight_number'
        )
        
        fig_time.update_traces(textposition="top center")
        fig_time.update_yaxis(tickformat='.0%')
        
        st.plotly_chart(fig_time, use_container_width=True)
```

### 💡 힌트
- Plotly는 인터랙티브 차트 제공
- `use_container_width=True`로 반응형 차트
- 히트맵은 패턴 파악에 유용

---

## 🎯 Feature 4: CSV 파일 업로드 기능

### 목표
CSV 파일을 업로드해서 여러 항공편을 한번에 예측

### Step 1: 파일 업로드 UI 추가
```python
# 새로운 탭 추가 또는 기존 탭에 섹션 추가
st.divider()
st.header("📂 CSV 파일 업로드")

# 샘플 CSV 생성 버튼
if st.button("📥 샘플 CSV 다운로드"):
    sample_data = pd.DataFrame({
        'arcft_flt_schd_ymd': [20251124, 20251124, 20251125, 20251125, 20251126],
        'arcft_flt_schd_hm': [800, 1200, 1400, 1600, 1000],
        'flt_fltnm': ['KE001', 'OZ101', 'LJ263', 'TW234', 'JE567']
    })
    
    csv = sample_data.to_csv(index=False)
    st.download_button(
        "💾 sample_flights.csv 다운로드",
        csv,
        "sample_flights.csv",
        "text/csv",
        key='download-sample'
    )
    st.info("다운로드한 파일을 수정하여 사용하세요!")

# 파일 업로더
uploaded_file = st.file_uploader(
    "CSV 파일을 선택하세요",
    type=['csv'],
    help="컬럼: arcft_flt_schd_ymd, arcft_flt_schd_hm, flt_fltnm"
)
```

### Step 2: 파일 처리 및 검증
```python
if uploaded_file is not None:
    try:
        # CSV 읽기
        df_upload = pd.read_csv(uploaded_file)
        
        # 필수 컬럼 확인
        required_cols = ['arcft_flt_schd_ymd', 'arcft_flt_schd_hm', 'flt_fltnm']
        missing_cols = [col for col in required_cols if col not in df_upload.columns]
        
        if missing_cols:
            st.error(f"❌ 필수 컬럼이 없습니다: {missing_cols}")
            st.stop()
        
        # 데이터 미리보기
        st.subheader("📋 업로드된 데이터")
        st.write(f"총 {len(df_upload)}개 항공편")
        
        # 처음 5개만 미리보기
        st.dataframe(df_upload.head(), use_container_width=True)
        
        # 데이터 검증
        st.subheader("✅ 데이터 검증")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            valid_dates = df_upload['arcft_flt_schd_ymd'].apply(
                lambda x: len(str(x)) == 8
            ).all()
            
            if valid_dates:
                st.success("날짜 형식 정상")
            else:
                st.error("날짜 형식 오류 (YYYYMMDD)")
        
        with col2:
            valid_times = df_upload['arcft_flt_schd_hm'].apply(
                lambda x: 0 <= x <= 2359
            ).all()
            
            if valid_times:
                st.success("시간 형식 정상")
            else:
                st.error("시간 형식 오류 (HHMM)")
        
        with col3:
            null_check = df_upload[required_cols].isnull().sum().sum() == 0
            
            if null_check:
                st.success("결측값 없음")
            else:
                st.error("결측값 존재")
        
    except Exception as e:
        st.error(f"파일 읽기 오류: {str(e)}")
```

### Step 3: 배치 예측 실행
```python
# 예측 실행 버튼
if uploaded_file and st.button("🚀 CSV 파일 예측 실행", type="primary"):
    
    # Progress bar
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    # API 요청 데이터 준비
    batch_data = {
        "flights": df_upload[required_cols].to_dict('records')
    }
    
    status_text.text("API 서버에 요청 중...")
    progress_bar.progress(30)
    
    try:
        # API 호출
        response = requests.post(
            f"{API_URL}/predict/batch",
            json=batch_data,
            timeout=30  # 타임아웃 설정
        )
        
        progress_bar.progress(60)
        
        if response.status_code == 200:
            results = response.json()
            predictions = results['predictions']
            
            # 결과를 원본 DataFrame에 추가
            df_upload['predicted_load_factor'] = [
                p['predicted_load_factor'] for p in predictions
            ]
            
            # 탑승률 수준 추가
            df_upload['load_level'] = df_upload['predicted_load_factor'].apply(
                lambda x: '높음 🔴' if x > 0.8 else '보통 🟡' if x > 0.6 else '낮음 🟢'
            )
            
            progress_bar.progress(90)
            
            # 결과 표시
            st.success(f"✅ {len(predictions)}개 항공편 예측 완료!")
            
            # 결과 요약
            st.subheader("📊 예측 결과 요약")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                avg_load = df_upload['predicted_load_factor'].mean()
                st.metric("평균 탑승률", f"{avg_load:.1%}")
            
            with col2:
                high_load = (df_upload['predicted_load_factor'] > 0.8).sum()
                st.metric("높은 탑승률", f"{high_load}개")
            
            with col3:
                low_load = (df_upload['predicted_load_factor'] < 0.5).sum()
                st.metric("낮은 탑승률", f"{low_load}개")
            
            # 전체 결과 표시
            st.subheader("📋 전체 예측 결과")
            
            # 표시할 컬럼 선택
            display_cols = ['flt_fltnm', 'arcft_flt_schd_ymd', 
                          'arcft_flt_schd_hm', 'predicted_load_factor', 
                          'load_level']
            
            # 포맷팅
            df_display = df_upload[display_cols].copy()
            df_display['predicted_load_factor'] = df_display['predicted_load_factor'].apply(
                lambda x: f"{x:.1%}"
            )
            
            # 컬럼명 한글로
            df_display.columns = ['항공편', '날짜', '시간', '예상 탑승률', '수준']
            
            st.dataframe(
                df_display,
                use_container_width=True,
                hide_index=True
            )
            
            progress_bar.progress(100)
            status_text.text("완료!")
            
            # 결과 다운로드
            st.divider()
            
            # CSV 다운로드
            result_csv = df_upload.to_csv(index=False, encoding='utf-8-sig')
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.download_button(
                    "📥 예측 결과 다운로드 (CSV)",
                    result_csv,
                    f"predictions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    "text/csv",
                    key='download-results'
                )
            
            with col2:
                # Excel 다운로드 (pandas 필요)
                import io
                buffer = io.BytesIO()
                with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
                    df_upload.to_excel(writer, index=False)
                
                st.download_button(
                    "📥 예측 결과 다운로드 (Excel)",
                    data=buffer.getvalue(),
                    file_name=f"predictions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key='download-excel'
                )
                
        else:
            st.error(f"예측 실패: {response.status_code}")
            
    except requests.exceptions.Timeout:
        st.error("⏱️ 요청 시간 초과. 데이터가 너무 많을 수 있습니다.")
    except Exception as e:
        st.error(f"오류 발생: {str(e)}")
    finally:
        progress_bar.empty()
        status_text.empty()
```

### Step 4: 차트 추가 (선택사항)
```python
# 예측 완료 후 시각화
if 'predicted_load_factor' in df_upload.columns:
    st.subheader("📈 예측 결과 시각화")
    
    # 탭으로 구분
    chart_tab1, chart_tab2, chart_tab3 = st.tabs(
        ["분포도", "시간별 패턴", "항공편별 비교"]
    )
    
    with chart_tab1:
        # 히스토그램
        fig_hist = px.histogram(
            df_upload,
            x='predicted_load_factor',
            nbins=20,
            title='탑승률 분포',
            labels={'predicted_load_factor': '예상 탑승률', 'count': '항공편 수'}
        )
        fig_hist.update_xaxis(tickformat='.0%')
        st.plotly_chart(fig_hist, use_container_width=True)
    
    with chart_tab2:
        # 시간별 평균
        df_upload['hour'] = df_upload['arcft_flt_schd_hm'] // 100
        hourly = df_upload.groupby('hour')['predicted_load_factor'].mean().reset_index()
        
        fig_time = px.bar(
            hourly,
            x='hour',
            y='predicted_load_factor',
            title='시간대별 평균 탑승률'
        )
        fig_time.update_yaxis(tickformat='.0%')
        st.plotly_chart(fig_time, use_container_width=True)
    
    with chart_tab3:
        # Top 10 항공편
        top10 = df_upload.nlargest(10, 'predicted_load_factor')
        
        fig_top = px.bar(
            top10,
            x='flt_fltnm',
            y='predicted_load_factor',
            title='탑승률 Top 10 항공편',
            color='predicted_load_factor',
            color_continuous_scale='RdYlGn'
        )
        fig_top.update_yaxis(tickformat='.0%')
        st.plotly_chart(fig_top, use_container_width=True)
```

### 💡 힌트
- 대용량 파일은 timeout 설정 필요
- Progress bar로 사용자 경험 향상
- Excel 다운로드는 openpyxl 패키지 필요
- 데이터 검증은 필수!

---

## 🎓 추가 학습 과제

### 1. 세션 상태 활용
```python
# 예측 결과를 세션에 저장
if 'prediction_history' not in st.session_state:
    st.session_state.prediction_history = []

# 예측 후 저장
st.session_state.prediction_history.append({
    'timestamp': datetime.now(),
    'flight': flight_number,
    'load_factor': load_factor
})

# 세션 히스토리 표시
if st.session_state.prediction_history:
    st.write("세션 내 예측 기록:")
    for record in st.session_state.prediction_history[-5:]:
        st.write(f"- {record['flight']}: {record['load_factor']:.1%}")
```

### 2. 캐싱 활용
```python
@st.cache_data(ttl=60)  # 60초 캐시
def fetch_logs(limit):
    response = requests.get(f"{API_URL}/logs?limit={limit}")
    return response.json() if response.status_code == 200 else []

# 캐시된 데이터 사용
logs = fetch_logs(100)
```

### 3. 커스텀 CSS
```python
# 커스텀 스타일 적용
st.markdown("""
<style>
    .stMetric {
        background-color: #f0f2f6;
        padding: 10px;
        border-radius: 5px;
    }
    .st-emotion-cache-1kyxreq {
        justify-content: center;
    }
</style>
""", unsafe_allow_html=True)
```

---

## 🚨 주의사항

1. **API 서버 실행 중인지 확인**
2. **포트 번호 일치 확인** (기본: 8000)
3. **대용량 데이터는 배치 크기 조절**
4. **세션 상태는 새로고침시 초기화**
5. **차트가 많으면 로딩 속도 저하**

---

## 📚 참고 자료

- [Streamlit 공식 문서](https://docs.streamlit.io)
- [Plotly Python](https://plotly.com/python/)
- [Pandas 문서](https://pandas.pydata.org/docs/)
- [FastAPI 문서](https://fastapi.tiangolo.com)

---

**다음 세션**: Docker 컨테이너화 및 배포
**문의**: 김승원 멘토
