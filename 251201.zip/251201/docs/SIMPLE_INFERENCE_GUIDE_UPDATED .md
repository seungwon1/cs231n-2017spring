# Simple Inference API 사용 가이드 + DB Integration

## 🎯 개요

이 시스템은 **Training**과 **Inference**를 완전히 분리한 구조에 **PostgreSQL 연동**을 추가했습니다:

```
🏋️ Training (train_model.py) → 💾 Model Weights → 🚀 Inference API (simple_api_with_db.py) ⟷ 🗄️ PostgreSQL
```

**새로운 기능:**
- 📝 모든 prediction 결과를 DB에 자동 저장
- 📊 예측 히스토리 조회 API
- 🔍 실시간 로그 모니터링

## 🚀 빠른 시작

### 0단계: PostgreSQL 및 DB 설정 🆕
```sql
-- pgAdmin에서 실행
CREATE DATABASE flight_load_predictor;

-- Query Tool에서 테이블 생성
CREATE TABLE IF NOT EXISTS prediction_logs (
    id SERIAL PRIMARY KEY,
    flight_number VARCHAR(10),
    flight_date INTEGER,
    flight_time INTEGER,
    predicted_load_factor FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 성능 향상을 위한 인덱스 추가
CREATE INDEX IF NOT EXISTS idx_prediction_logs_flight ON prediction_logs(flight_number);
CREATE INDEX IF NOT EXISTS idx_prediction_logs_date ON prediction_logs(flight_date);
```

### 1단계: 모델 학습 및 저장
```bash
# 샘플 데이터로 학습
python train_model.py --model-type random_forest

# 또는 실제 CSV 데이터로 학습
python train_model.py --data data/gd_sample.csv --model-type random_forest
```

**결과:** `model_weights/` 폴더에 모델 파일들이 저장됩니다.

### 2단계: DB 연동 Inference API 서버 시작 🆕
```bash
# DB 연결 정보 수정 (simple_api_with_db.py 파일에서)
# DB_CONFIG = {
#     'host': 'localhost',
#     'port': '5432', 
#     'database': 'flight_load_predictor',
#     'user': 'postgres',
#     'password': 'your_actual_password'  # 이 부분만 수정!
# }

# DB 연동 서버 시작
python simple_api_with_db.py --model-dir model_weights

# 포트 변경
python simple_api_with_db.py --model-dir model_weights --port 8080
```

### 3단계: API 테스트
```bash
# 자동 테스트 실행
python test_inference.py

# 특정 인천공항 항공편 테스트
python test_inference.py --incheon-only
```

## 📁 파일 구조

```
model_weights/
├── preprocessor.joblib      # 전처리기
├── predictor.joblib         # ML 모델
└── model_metadata.json      # 모델 정보

simple_api_server.py         # 기본 Inference API 서버
simple_api_with_db.py        # 🆕 DB 연동 API 서버
simple_setup.sql             # 🆕 DB 테이블 설정 스크립트
train_model.py              # 학습 스크립트
test_inference.py           # API 테스트
```

## 🔧 API 엔드포인트

### 기본 상태 확인
```bash
curl http://localhost:8000/
curl http://localhost:8000/status
```

### 🆕 예측 히스토리 조회 (DB에서 읽기)
```bash
# 최근 10개 예측 로그 조회
curl http://localhost:8000/logs

# 최근 20개 조회
curl "http://localhost:8000/logs?limit=20"
```

**응답:**
```json
[
  {
    "id": 1,
    "flight_number": "LJ263",
    "flight_date": 20251115,
    "flight_time": 1430,
    "predicted_load_factor": 0.8542,
    "created_at": "2024-11-15T14:30:00"
  },
  {
    "id": 2,
    "flight_number": "KE123", 
    "flight_date": 20251115,
    "flight_time": 1600,
    "predicted_load_factor": 0.7234,
    "created_at": "2024-11-15T16:00:00"
  }
]
```

### 단일 항공편 예측 (자동 DB 저장)
```bash
curl -X POST "http://localhost:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "arcft_flt_schd_ymd": 20251115,
    "arcft_flt_schd_hm": 1430,
    "flt_fltnm": "LJ263"
  }'
```

**응답:**
```json
{
  "flight_info": {
    "arcft_flt_schd_ymd": 20251115,
    "arcft_flt_schd_hm": 1430,
    "flt_fltnm": "LJ263"
  },
  "predicted_load_factor": 0.8542,
  "prediction_time": "2024-11-15T14:30:00"
}
```

> 🔥 **자동 DB 저장**: 예측을 실행할 때마다 결과가 자동으로 `prediction_logs` 테이블에 저장됩니다!

### 배치 예측
```bash
curl -X POST "http://localhost:8000/predict/batch" \
  -H "Content-Type: application/json" \
  -d '{
    "flights": [
      {
        "arcft_flt_schd_ymd": 20251115,
        "arcft_flt_schd_hm": 800,
        "flt_fltnm": "KE001"
      },
      {
        "arcft_flt_schd_ymd": 20251115,
        "arcft_flt_schd_hm": 1200,
        "flt_fltnm": "OZ101"
      }
    ]
  }'
```

## 💻 Python 클라이언트 사용

```python
import requests

# API 초기화
api_url = "http://localhost:8000"

# 단일 예측 (자동으로 DB에 저장됨)
flight = {
    "arcft_flt_schd_ymd": 20251115,
    "arcft_flt_schd_hm": 1430,
    "flt_fltnm": "LJ263"
}

response = requests.post(f"{api_url}/predict", json=flight)
result = response.json()

print(f"예상 탑승률: {result['predicted_load_factor']:.1%}")
# 출력: 예상 탑승률: 85.4%

# 🆕 예측 히스토리 조회
logs_response = requests.get(f"{api_url}/logs?limit=5")
logs = logs_response.json()

print("최근 5개 예측 기록:")
for log in logs:
    print(f"- {log['flight_number']}: {log['predicted_load_factor']:.1%} ({log['created_at']})")
```

## 🏭 인천공항 실제 사용 시나리오

### 시나리오 1: 일일 탑승률 예측 + DB 저장
```python
# 하루 스케줄 가져오기 (실제 DB 쿼리)
daily_flights = get_flights_from_database("2025-11-15")

# API로 배치 예측 (자동으로 DB에 저장됨)
flights_data = []
for flight in daily_flights:
    flights_data.append({
        "arcft_flt_schd_ymd": int(flight['date'].strftime('%Y%m%d')),
        "arcft_flt_schd_hm": int(flight['time'].strftime('%H%M')),
        "flt_fltnm": flight['flight_number']
    })

response = requests.post(f"{api_url}/predict/batch", 
                        json={"flights": flights_data})
predictions = response.json()

# 🆕 예측 결과는 이미 DB에 저장됨! 별도 저장 불필요
print(f"✅ {len(predictions['predictions'])}개 항공편 예측 완료 및 DB 저장 완료")
```

### 🆕 시나리오 2: 실시간 대시보드용 데이터 조회
```python
# 오늘 예측된 항공편들의 평균 탑승률 조회
def get_daily_load_factor_stats(date):
    """특정 날짜의 예측 통계 조회"""
    date_int = int(date.replace('-', ''))
    
    # PostgreSQL에서 직접 조회 (더 빠름)
    query = """
    SELECT 
        COUNT(*) as total_flights,
        AVG(predicted_load_factor) as avg_load_factor,
        MIN(predicted_load_factor) as min_load_factor,
        MAX(predicted_load_factor) as max_load_factor
    FROM prediction_logs 
    WHERE flight_date = %s
    """
    
    # 또는 API를 통한 조회
    logs_response = requests.get(f"{api_url}/logs?limit=1000")
    logs = logs_response.json()
    
    today_logs = [log for log in logs if log['flight_date'] == date_int]
    
    return {
        'total_flights': len(today_logs),
        'avg_load_factor': sum(log['predicted_load_factor'] for log in today_logs) / len(today_logs),
        'peak_hours': analyze_peak_hours(today_logs)
    }

# 실시간 모니터링
stats = get_daily_load_factor_stats('2025-11-15')
print(f"오늘 {stats['total_flights']}개 항공편, 평균 탑승률: {stats['avg_load_factor']:.1%}")
```

### 시나리오 3: 실시간 예측 서비스
```python
from fastapi import FastAPI
import requests

app = FastAPI()

@app.get("/flight/{flight_code}/load-factor")
async def get_load_factor(flight_code: str, date: str, time: str):
    """실시간 탑승률 조회 API"""
    
    # 날짜/시간 파싱
    date_int = int(date.replace('-', ''))
    time_int = int(time.replace(':', ''))
    
    # ML API 호출
    ml_response = requests.post("http://localhost:8000/predict", json={
        "arcft_flt_schd_ymd": date_int,
        "arcft_flt_schd_hm": time_int,
        "flt_fltnm": flight_code
    })
    
    result = ml_response.json()
    
    return {
        "flight_code": flight_code,
        "predicted_load_factor": result["predicted_load_factor"],
        "prediction_confidence": "high",  # 모델 성능 기반
        "last_updated": result["prediction_time"]
    }
```

## 🔄 모델 업데이트 프로세스

### 1. 새로운 데이터로 재학습
```bash
# 최신 데이터 추출 (예: 최근 3개월)
python extract_training_data.py --start-date 2024-08-01 --end-date 2024-10-31

# 모델 재학습
python train_model.py --data latest_data.csv --model-type random_forest

# 성능 비교 후 배포 결정
```

### 2. 무중단 모델 교체
```bash
# 기존 모델 백업
cp -r model_weights model_weights_backup_$(date +%Y%m%d)

# 새 모델 배포
cp -r new_model_weights model_weights

# API에서 모델 재로드 (서버 재시작 없이)
curl -X POST "http://localhost:8000/reload"
```

## 📊 성능 최적화

### 메모리 사용량 최소화
- Inference 전용 서버는 **학습 코드 없음**
- 필요한 라이브러리만 설치: `inference_requirements.txt`
- 모델 가중치만 메모리에 로드

### 응답 속도 최적화
- 전처리기와 모델 **미리 로드**
- 배치 예측으로 **여러 항공편 한번에 처리**
- numpy 벡터화 연산 활용

### 확장성 고려사항
```bash
# 다중 인스턴스 실행 (로드밸런싱)
python simple_api_server.py --port 8000 &
python simple_api_server.py --port 8001 &
python simple_api_server.py --port 8002 &

# nginx 로드밸런서 설정
upstream ml_api {
    server localhost:8000;
    server localhost:8001; 
    server localhost:8002;
}
```

## 🐳 Docker 배포 (DB 연동 버전) 🆕

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# 의존성 설치 (psycopg2 포함)
COPY requirements.txt .
RUN apt-get update && apt-get install -y libpq-dev gcc \
    && pip install -r requirements.txt \
    && apt-get clean

# 필요한 파일만 복사
COPY enhanced_avtn_preprocessor.py .
COPY flight_load_predictor.py .
COPY simple_api_with_db.py .
COPY model_weights/ ./model_weights/

# 환경변수 설정
ENV DB_HOST=postgres
ENV DB_PORT=5432
ENV DB_NAME=flight_load_predictor
ENV DB_USER=postgres
ENV DB_PASSWORD=your_password

EXPOSE 8000

CMD ["python", "simple_api_with_db.py", "--model-dir", "model_weights"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: flight_load_predictor
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: your_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./simple_setup.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"
  
  api:
    build: .
    environment:
      DB_HOST: postgres
      DB_PASSWORD: your_password
    ports:
      - "8000:8000"
    depends_on:
      - postgres

volumes:
  postgres_data:
```

```bash
# 실행
docker-compose up -d

# API 테스트
curl http://localhost:8000/
curl http://localhost:8000/logs
```

## 🔒 보안 및 모니터링

### API 키 보호 (프로덕션 환경)
```python
# simple_api_with_db.py에 추가
from fastapi.security import APIKeyHeader

API_KEY = "your-secret-api-key"
api_key_header = APIKeyHeader(name="X-API-Key")

@app.post("/predict")
async def predict_single(flight: FlightData, api_key: str = Depends(api_key_header)):
    if api_key != API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API key")
    # 기존 예측 로직...
```

### 🆕 DB 기반 로그 모니터링
```bash
# API 서버 로그 모니터링
tail -f /var/log/flight-predictor/api.log | grep "ERROR\|WARNING"

# 성능 지표 수집
curl http://localhost:8000/status | jq '.model_loaded'

# 🆕 PostgreSQL에서 직접 통계 조회
psql -d flight_load_predictor -c "
SELECT 
    DATE(created_at) as date,
    COUNT(*) as predictions_count,
    AVG(predicted_load_factor) as avg_load_factor,
    MIN(predicted_load_factor) as min_load_factor,
    MAX(predicted_load_factor) as max_load_factor
FROM prediction_logs 
WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;
"

# 🆕 특정 항공편 예측 히스토리
psql -d flight_load_predictor -c "
SELECT flight_number, flight_date, predicted_load_factor, created_at 
FROM prediction_logs 
WHERE flight_number = 'LJ263' 
ORDER BY created_at DESC 
LIMIT 10;
"
```

### 🆕 실시간 대시보드 쿼리 예시
```sql
-- 시간대별 예측 건수
SELECT 
    EXTRACT(HOUR FROM created_at) as hour,
    COUNT(*) as predictions_count
FROM prediction_logs 
WHERE DATE(created_at) = CURRENT_DATE
GROUP BY EXTRACT(HOUR FROM created_at)
ORDER BY hour;

-- 탑승률 분포
SELECT 
    CASE 
        WHEN predicted_load_factor < 0.3 THEN '낮음 (<30%)'
        WHEN predicted_load_factor < 0.7 THEN '보통 (30-70%)'
        ELSE '높음 (>70%)'
    END as load_category,
    COUNT(*) as flight_count
FROM prediction_logs 
WHERE DATE(created_at) = CURRENT_DATE
GROUP BY 
    CASE 
        WHEN predicted_load_factor < 0.3 THEN '낮음 (<30%)'
        WHEN predicted_load_factor < 0.7 THEN '보통 (30-70%)'
        ELSE '높음 (>70%)'
    END;
```

이제 **Training**과 **Inference**가 완전히 분리된 깔끔한 시스템에 **PostgreSQL 연동**까지 추가되어 완벽한 프로덕션 환경이 준비되었습니다! 🎉

## ✨ 주요 개선사항

- 🔄 **기존 기능 유지**: 모든 예측 API는 동일하게 작동
- 📝 **자동 로깅**: 모든 예측 결과가 자동으로 DB에 저장
- 📊 **히스토리 조회**: `/logs` API로 예측 기록 조회 가능
- 🔍 **실시간 모니터링**: PostgreSQL 쿼리로 상세한 통계 분석
- 🚫 **장애 안전**: DB 연결 실패해도 예측 기능은 정상 동작
- ⚡ **단순함**: 복잡한 ORM 없이 순수 SQL로 간단 구현
