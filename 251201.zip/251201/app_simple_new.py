import streamlit as st
import requests
import pandas as pd
from datetime import datetime, time

# ============ 세션 상태 초기화 ============
if 'prediction_history' not in st.session_state:
    st.session_state.prediction_history = []

# ============ 캐싱 함수 ============
@st.cache_data(ttl=60)  # 60초 동안 캐시 유지
def check_api_status():
    """API 상태 확인 (캐싱 적용)"""
    try:
        response = requests.get(f"{API_URL}/status", timeout=2)
        return response.status_code == 200
    except:
        return False

@st.cache_data(ttl=30)  # 30초 동안 캐시 유지
def fetch_logs(limit):
    """로그 조회 (캐싱 적용)"""
    try:
        response = requests.get(f"{API_URL}/logs?limit={limit}")
        return response.json() if response.status_code == 200 else []
    except:
        return []


# 페이지 설정
st.set_page_config(
    page_title="✈️ 항공편 탑승률 예측",
    page_icon="✈️",
    layout="wide"  # centered → wide 변경
)

# 제목
st.title("✈️ 항공편 탑승률 예측 시스템")
st.markdown("간단한 예측 테스트 페이지")

# API 서버 URL
API_URL = "http://localhost:8000"

if check_api_status():
    st.sidebar.success("✅ API 정상")
else:
    st.sidebar.error("❌ API 오프라인")

if st.sidebar.button("🔄 새로고침"):
    st.cache_data.clear()
    st.rerun()

# 탭 생성
tab1, tab2 = st.tabs(["🎯 예측하기", "📜 히스토리"])

# Tab 1: 예측 기능
with tab1:
    st.header("📝 항공편 정보 입력")

    # 기존 입력 폼 코드...

    col1, col2 = st.columns(2)

    with col1:
        # 날짜 입력
        flight_date = st.date_input(
            "운항 날짜",
            value=datetime(2025, 11, 24)
        )

        # 시간 입력
        flight_time = st.time_input(
            "운항 시간",
            value=time(14, 30)
        )

    with col2:
        # 항공편명 입력
        flight_number = st.text_input(
            "항공편명",
            value="KE001",
            help="예: KE001, OZ101, LJ263"
        )

        # 예측 버튼
        st.write("")  # 공백
        st.write("")  # 공백
        predict_button = st.button(
            "🔮 예측하기",
            use_container_width=True,
            type="primary"
        )


# Tab 2: 히스토리
with tab2:
    st.header("📜 예측 히스토리")

    limit = st.selectbox("조회 개수", [10, 20, 50], index=0)

    logs = fetch_logs(limit)  # 캐싱된 함수 사용

    if logs:
        df = pd.DataFrame(logs)
        st.dataframe(df, use_container_width=True, hide_index=True)

        import plotly.express as px
        # Tab 2 내부, 데이터프레임 표시 후
        if logs and len(df) > 1:
            st.subheader("📊 탑승률 분포")

            # 히스토그램
            fig = px.histogram(
                df,
                x='predicted_load_factor',
                nbins=20,
                title='예측 탑승률 분포'
            )
            fig.update_layout(
                xaxis_title='탑승률',
                yaxis_title='빈도',
                xaxis_tickformat='.0%'
            )
            st.plotly_chart(fig, use_container_width=True)


        # 간단한 통계
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("총 예측 수", len(df))
        with col2:
            st.metric("평균 탑승률", f"{df['predicted_load_factor'].mean():.1%}")
        with col3:
            st.metric("최고 탑승률", f"{df['predicted_load_factor'].max():.1%}")
    else:
        st.info("예측 기록이 없습니다.")



# 예측 실행
if predict_button:
    # 날짜/시간 변환
    date_int = int(flight_date.strftime("%Y%m%d"))
    time_int = int(flight_time.strftime("%H%M"))

    # API 요청 데이터
    request_data = {
        "arcft_flt_schd_ymd": date_int,
        "arcft_flt_schd_hm": time_int,
        "flt_fltnm": flight_number
    }

    # 로딩 표시
    with st.spinner("예측 중..."):
        try:
            # API 호출
            response = requests.post(
                f"{API_URL}/predict",
                json=request_data
            )

            if response.status_code == 200:
                # 결과 파싱
                result = response.json()
                load_factor = result["predicted_load_factor"]

                # 성공 메시지
                st.success("✅ 예측 완료!")

                # 세션에 예측 결과 저장
                st.session_state.prediction_history.append({
                    'flight': flight_number,
                    'load_factor': load_factor,
                    'timestamp': datetime.now().strftime("%H:%M:%S")
                })

                # 결과 표시
                st.divider()
                st.header("📊 예측 결과")

                # 메트릭 표시
                col1, col2, col3 = st.columns(3)

                with col1:
                    st.metric(
                        "항공편",
                        flight_number
                    )

                with col2:
                    st.metric(
                        "예상 탑승률",
                        f"{load_factor:.1%}"
                    )

                with col3:
                    # 탑승률 수준 판단
                    if load_factor > 0.8:
                        level = "높음 🔴"
                    elif load_factor > 0.6:
                        level = "보통 🟡"
                    else:
                        level = "낮음 🟢"

                    st.metric(
                        "탑승률 수준",
                        level
                    )

                import plotly.express as px
                import plotly.graph_objects as go

                # Gauge 차트로 시각화
                fig = go.Figure(go.Indicator(
                    mode="gauge+number",
                    value=load_factor * 100,
                    title={'text': "탑승률 (%)"},
                    gauge={
                        'axis': {'range': [0, 100]},
                        'bar': {'color': "darkblue"},
                        'steps': [
                            {'range': [0, 50], 'color': "lightgreen"},
                            {'range': [50, 80], 'color': "yellow"},
                            {'range': [80, 100], 'color': "salmon"}
                        ]
                    }
                ))
                fig.update_layout(height=300)
                st.plotly_chart(fig, use_container_width=True)

                # Progress bar로 시각화
                st.progress(load_factor)

                # 상세 정보
                with st.expander("📋 상세 정보 보기"):
                    st.json(result)

                    # 요청 정보도 표시
                    st.write("**요청 데이터:**")
                    st.json(request_data)

            else:
                st.error(f"❌ 예측 실패 (상태 코드: {response.status_code})")

        except requests.exceptions.ConnectionError:
            st.error("❌ API 서버에 연결할 수 없습니다. 서버가 실행 중인지 확인하세요.")
        except Exception as e:
            st.error(f"❌ 오류 발생: {str(e)}")

    # 세션 내 예측 기록 표시
    if st.session_state.prediction_history:
        st.divider()
        st.subheader("📝 이번 세션 예측 기록")
        for i, record in enumerate(st.session_state.prediction_history[-5:], 1):
            st.write(f"{i}. **{record['flight']}**: {record['load_factor']:.1%} ({record['timestamp']})")

# 하단 정보
st.divider()
st.caption("ML Systems Design 클래스 - Session 7")
st.caption("💡 팁: API 서버가 실행 중이어야 예측이 가능합니다.")