"""
Simple Inference-Only API Server for Flight Load Prediction
Loads pre-trained model weights and serves predictions
+ Simple DB connection for prediction logging
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
import pandas as pd
import numpy as np
import joblib
import json
import os
import logging
from datetime import datetime
import uvicorn
import psycopg2
from psycopg2.extras import RealDictCursor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Flight Load Predictor - Inference API with DB",
    description="Lightweight inference server with simple DB logging",
    version="1.1.0"
)

# Simple DB config - 실제 값으로 수정하세요
DB_CONFIG = {
    'host': 'localhost',
    'port': '5432',
    'database': 'flight_load_predictor',  # 또는 기존 DB 이름
    'user': 'postgres',
    'password': 'postgres'  # 실제 비밀번호로 수정
}


# Simple DB connection function
def get_db_connection():
    """간단한 DB 연결"""
    try:
        return psycopg2.connect(**DB_CONFIG, cursor_factory=RealDictCursor)
    except Exception as e:
        logger.error(f"DB 연결 실패: {e}")
        return None


# Global model components
preprocessor = None
predictor = None
model_metadata = None


# Request/Response models
class FlightData(BaseModel):
    """Flight data for prediction"""
    arcft_flt_schd_ymd: int = Field(..., description="Flight date (YYYYMMDD)", example=20251115)
    arcft_flt_schd_hm: int = Field(..., description="Flight time (HHMM)", example=1430)
    flt_fltnm: str = Field(..., description="Flight number", example="LJ263")


class BatchRequest(BaseModel):
    """Batch prediction request"""
    flights: List[FlightData]


class PredictionResponse(BaseModel):
    """Prediction response"""
    flight_info: FlightData
    predicted_load_factor: float
    prediction_time: str


class BatchResponse(BaseModel):
    """Batch prediction response"""
    predictions: List[PredictionResponse]
    total_flights: int
    avg_load_factor: float
    processing_time_ms: float


class ModelInfo(BaseModel):
    """Model information"""
    model_loaded: bool
    model_type: Optional[str] = None
    training_date: Optional[str] = None
    feature_count: Optional[int] = None
    test_r2: Optional[float] = None
    test_mae: Optional[float] = None


# 🆕 New DB-related models
class PredictionLogResponse(BaseModel):
    """Prediction log response"""
    id: int
    flight_number: str
    flight_date: int
    flight_time: int
    predicted_load_factor: float
    created_at: str


def load_model_weights(model_dir: str = "model_weights"):
    """
    Load pre-trained model weights from local directory

    :param model_dir: Directory containing model files
    """
    global preprocessor, predictor, model_metadata

    try:
        logger.info(f"🔄 Loading model from {model_dir}")

        # Check required files
        required_files = {
            'preprocessor': f"{model_dir}/preprocessor.joblib",
            'predictor': f"{model_dir}/predictor.joblib",
            'metadata': f"{model_dir}/model_metadata.json"
        }

        for name, path in required_files.items():
            if not os.path.exists(path):
                raise FileNotFoundError(f"Missing {name} file: {path}")

        # Load components
        logger.info("📦 Loading preprocessor...")
        preprocessor = joblib.load(required_files['preprocessor'])

        logger.info("🤖 Loading predictor...")
        predictor = joblib.load(required_files['predictor'])

        logger.info("📄 Loading metadata...")
        with open(required_files['metadata'], 'r') as f:
            model_metadata = json.load(f)

        # Validate components
        if not hasattr(preprocessor, 'is_fitted') or not preprocessor.is_fitted:
            raise ValueError("Preprocessor is not fitted")

        if not hasattr(predictor, 'is_trained') or not predictor.is_trained:
            raise ValueError("Predictor is not trained")

        logger.info("✅ Model components loaded successfully")
        logger.info(f"   Model type: {model_metadata['model_type']}")
        logger.info(f"   Training date: {model_metadata['training_date']}")
        logger.info(f"   Features: {len(model_metadata['feature_names'])}")

        if 'metrics' in model_metadata:
            metrics = model_metadata['metrics']
            logger.info(f"   Test R²: {metrics.get('test_r2', 'N/A')}")
            logger.info(f"   Test MAE: {metrics.get('test_mae', 'N/A')}")

        return True

    except Exception as e:
        logger.error(f"❌ Failed to load model: {e}")
        return False


@app.on_event("startup")
async def startup_event():
    """Load model on startup and setup DB table"""
    import argparse
    import sys

    # Try to get model directory from command line args
    model_dir = "model_weights"  # Default

    # Check if --model-dir was passed
    if "--model-dir" in sys.argv:
        idx = sys.argv.index("--model-dir")
        if idx + 1 < len(sys.argv):
            model_dir = sys.argv[idx + 1]

    success = load_model_weights(model_dir)
    if not success:
        logger.warning("⚠️ Model not loaded. Use /reload endpoint to load manually.")

    # 🆕 간단한 DB 테이블 생성
    setup_db_table()


def setup_db_table():
    """간단한 prediction log 테이블 생성"""
    conn = get_db_connection()
    if not conn:
        logger.warning("⚠️ DB 연결 실패 - DB 기능 사용불가")
        return

    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS prediction_logs (
                    id SERIAL PRIMARY KEY,
                    flight_number VARCHAR(10),
                    flight_date INTEGER,
                    flight_time INTEGER,
                    predicted_load_factor FLOAT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
            logger.info("✅ DB 테이블 준비 완료")
    except Exception as e:
        logger.error(f"❌ DB 테이블 생성 실패: {e}")
    finally:
        conn.close()


# Health check
@app.get("/")
async def root():
    """Health check"""
    # 🆕 DB 연결 테스트도 추가
    db_status = "connected" if get_db_connection() else "disconnected"

    return {
        "service": "Flight Load Predictor - Inference API with DB",
        "status": "running",
        "model_loaded": preprocessor is not None and predictor is not None,
        "database_status": db_status,
        "timestamp": datetime.now().isoformat()
    }


# Model status
@app.get("/status", response_model=ModelInfo)
async def get_status():
    """Get model status and information"""
    if not preprocessor or not predictor or not model_metadata:
        return ModelInfo(model_loaded=False)

    metrics = model_metadata.get('metrics', {})
    return ModelInfo(
        model_loaded=True,
        model_type=model_metadata.get('model_type'),
        training_date=model_metadata.get('training_date'),
        feature_count=len(model_metadata.get('feature_names', [])),
        test_r2=metrics.get('test_r2'),
        test_mae=metrics.get('test_mae')
    )


# Reload model
@app.post("/reload")
async def reload_model(model_dir: str = "model_weights"):
    """Manually reload model from directory"""
    success = load_model_weights(model_dir)
    return {
        "success": success,
        "message": "Model reloaded successfully" if success else "Failed to reload model",
        "model_dir": model_dir
    }


# Single prediction (수정: DB에 로그 저장)
@app.post("/predict", response_model=PredictionResponse)
async def predict_single(flight: FlightData):
    """
    Predict load factor for a single flight

    Args:
        flight: Flight information for prediction
    """
    if not preprocessor or not predictor:
        raise HTTPException(
            status_code=503,
            detail="Model not loaded. Use /reload endpoint to load model."
        )

    try:
        start_time = datetime.now()

        # Convert to DataFrame
        df = pd.DataFrame([{
            'arcft_flt_schd_ymd': flight.arcft_flt_schd_ymd,
            'arcft_flt_schd_hm': flight.arcft_flt_schd_hm,
            'flt_fltnm': flight.flt_fltnm
        }])

        # Transform and predict
        X_processed = preprocessor.transform_new_data(df)
        prediction = predictor.predict(X_processed)[0]

        # Clip to valid range
        prediction = float(np.clip(prediction, 0.0, 1.0))

        # 🆕 DB에 prediction log 저장
        save_prediction_to_db(flight, prediction)

        return PredictionResponse(
            flight_info=flight,
            predicted_load_factor=round(prediction, 4),
            prediction_time=datetime.now().isoformat()
        )

    except Exception as e:
        logger.error(f"❌ Prediction error: {e}")
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


# 🆕 DB에 prediction 저장하는 함수
def save_prediction_to_db(flight: FlightData, prediction: float):
    """간단하게 prediction을 DB에 저장"""
    conn = get_db_connection()
    if not conn:
        return  # DB 연결 실패시 그냥 넘어감

    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO prediction_logs 
                (flight_number, flight_date, flight_time, predicted_load_factor)
                VALUES (%s, %s, %s, %s)
            """, (
                flight.flt_fltnm,
                flight.arcft_flt_schd_ymd,
                flight.arcft_flt_schd_hm,
                prediction
            ))
            conn.commit()
            logger.info(f"💾 Prediction saved to DB: {flight.flt_fltnm}")
    except Exception as e:
        logger.error(f"❌ DB 저장 실패: {e}")
    finally:
        conn.close()


# 🆕 DB에서 prediction log 읽기
@app.get("/logs", response_model=List[PredictionLogResponse])
async def get_prediction_logs(limit: int = 10):
    """
    최근 prediction 로그 조회 (DB에서 읽기)

    Args:
        limit: 가져올 로그 개수 (기본 10개)
    """
    conn = get_db_connection()
    if not conn:
        raise HTTPException(status_code=503, detail="Database connection failed")

    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT id, flight_number, flight_date, flight_time, 
                       predicted_load_factor, created_at
                FROM prediction_logs 
                ORDER BY created_at DESC 
                LIMIT %s
            """, (limit,))

            results = cursor.fetchall()

        logs = []
        for row in results:
            logs.append(PredictionLogResponse(
                id=row['id'],
                flight_number=row['flight_number'],
                flight_date=row['flight_date'],
                flight_time=row['flight_time'],
                predicted_load_factor=row['predicted_load_factor'],
                created_at=row['created_at'].isoformat()
            ))

        return logs

    except Exception as e:
        logger.error(f"❌ DB 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"Database query failed: {str(e)}")
    finally:
        conn.close()


# Batch prediction
@app.post("/predict/batch", response_model=BatchResponse)
async def predict_batch(request: BatchRequest):
    """
    Predict load factors for multiple flights

    Args:
        request: Batch of flight information
    """
    if not preprocessor or not predictor:
        raise HTTPException(
            status_code=503,
            detail="Model not loaded. Use /reload endpoint to load model."
        )

    try:
        start_time = datetime.now()

        # Convert to DataFrame
        flights_data = []
        for flight in request.flights:
            flights_data.append({
                'arcft_flt_schd_ymd': flight.arcft_flt_schd_ymd,
                'arcft_flt_schd_hm': flight.arcft_flt_schd_hm,
                'flt_fltnm': flight.flt_fltnm
            })

        df = pd.DataFrame(flights_data)

        # Transform and predict
        X_processed = preprocessor.transform_new_data(df)
        predictions_array = predictor.predict(X_processed)

        # Clip predictions
        predictions_array = np.clip(predictions_array, 0.0, 1.0)

        # Build response and save to DB
        predictions = []
        for i, flight in enumerate(request.flights):
            prediction_value = float(predictions_array[i])

            # 🆕 각 prediction을 DB에 저장
            save_prediction_to_db(flight, prediction_value)

            pred_response = PredictionResponse(
                flight_info=flight,
                predicted_load_factor=round(prediction_value, 4),
                prediction_time=datetime.now().isoformat()
            )
            predictions.append(pred_response)

        # Calculate stats
        end_time = datetime.now()
        processing_time = (end_time - start_time).total_seconds() * 1000
        avg_load_factor = float(np.mean(predictions_array))

        return BatchResponse(
            predictions=predictions,
            total_flights=len(predictions),
            avg_load_factor=round(avg_load_factor, 4),
            processing_time_ms=round(processing_time, 2)
        )

    except Exception as e:
        logger.error(f"❌ Batch prediction error: {e}")
        raise HTTPException(status_code=500, detail=f"Batch prediction failed: {str(e)}")


# Simple test endpoint
@app.get("/test")
async def test_prediction():
    """Test endpoint with sample prediction"""
    if not preprocessor or not predictor:
        raise HTTPException(
            status_code=503,
            detail="Model not loaded. Use /reload endpoint to load model."
        )

    # Sample flight data
    sample_flight = FlightData(
        arcft_flt_schd_ymd=20251115,
        arcft_flt_schd_hm=1430,
        flt_fltnm="LJ263"
    )

    return await predict_single(sample_flight)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Flight Load Predictor Inference Server with DB')
    parser.add_argument('--model-dir', type=str, default='model_weights',
                        help='Directory containing model weights')
    parser.add_argument('--host', type=str, default='0.0.0.0',
                        help='Host to bind to')
    parser.add_argument('--port', type=int, default=8000,
                        help='Port to bind to')
    parser.add_argument('--reload', action='store_true',
                        help='Enable auto-reload for development')

    args = parser.parse_args()

    # Load model first
    print(f"🚀 Starting Flight Load Predictor Inference Server with DB")
    print(f"📂 Model directory: {args.model_dir}")
    print(f"🗄️ Database: {DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}")

    # Run server
    uvicorn.run(
        "simple_api_with_db:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="info"
    )