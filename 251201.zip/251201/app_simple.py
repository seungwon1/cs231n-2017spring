import streamlit as st
import requests
import pandas as pd
from datetime import datetime, time

# 페이지 설정
st.set_page_config(
    page_title="✈️ 항공편 탑승률 예측",
    page_icon="✈️",
    layout="centered"
)

# 제목
st.title("✈️ 항공편 탑승률 예측 시스템")
st.markdown("간단한 예측 테스트 페이지")

# API 서버 URL
API_URL = "http://localhost:8000"

# API 상태 체크
st.sidebar.header("🔌 API 서버 상태")
if st.sidebar.button("연결 테스트"):
    try:
        response = requests.get(f"{API_URL}/status")
        if response.status_code == 200:
            st.sidebar.success("✅ API 서버 정상 작동")
        else:
            st.sidebar.error("❌ API 서버 응답 없음")
    except:
        st.sidebar.error("❌ API 서버 연결 실패")

st.divider()

# 예측 입력 폼
st.header("📝 항공편 정보 입력")

col1, col2 = st.columns(2)

with col1:
    # 날짜 입력
    flight_date = st.date_input(
        "운항 날짜",
        value=datetime(2025, 11, 24)
    )

    # 시간 입력
    flight_time = st.time_input(
        "운항 시간",
        value=time(14, 30)
    )

with col2:
    # 항공편명 입력
    flight_number = st.text_input(
        "항공편명",
        value="KE001",
        help="예: KE001, OZ101, LJ263"
    )

    # 예측 버튼
    st.write("")  # 공백
    st.write("")  # 공백
    predict_button = st.button(
        "🔮 예측하기",
        use_container_width=True,
        type="primary"
    )

# 예측 실행
if predict_button:
    # 날짜/시간 변환
    date_int = int(flight_date.strftime("%Y%m%d"))
    time_int = int(flight_time.strftime("%H%M"))

    # API 요청 데이터
    request_data = {
        "arcft_flt_schd_ymd": date_int,
        "arcft_flt_schd_hm": time_int,
        "flt_fltnm": flight_number
    }

    # 로딩 표시
    with st.spinner("예측 중..."):
        try:
            # API 호출
            response = requests.post(
                f"{API_URL}/predict",
                json=request_data
            )

            if response.status_code == 200:
                # 결과 파싱
                result = response.json()
                load_factor = result["predicted_load_factor"]

                # 성공 메시지
                st.success("✅ 예측 완료!")

                # 결과 표시
                st.divider()
                st.header("📊 예측 결과")

                # 메트릭 표시
                col1, col2, col3 = st.columns(3)

                with col1:
                    st.metric(
                        "항공편",
                        flight_number
                    )

                with col2:
                    st.metric(
                        "예상 탑승률",
                        f"{load_factor:.1%}"
                    )

                with col3:
                    # 탑승률 수준 판단
                    if load_factor > 0.8:
                        level = "높음 🔴"
                    elif load_factor > 0.6:
                        level = "보통 🟡"
                    else:
                        level = "낮음 🟢"

                    st.metric(
                        "탑승률 수준",
                        level
                    )

                # Progress bar로 시각화
                st.progress(load_factor)

                # 상세 정보
                with st.expander("📋 상세 정보 보기"):
                    st.json(result)

                    # 요청 정보도 표시
                    st.write("**요청 데이터:**")
                    st.json(request_data)

            else:
                st.error(f"❌ 예측 실패 (상태 코드: {response.status_code})")

        except requests.exceptions.ConnectionError:
            st.error("❌ API 서버에 연결할 수 없습니다. 서버가 실행 중인지 확인하세요.")
        except Exception as e:
            st.error(f"❌ 오류 발생: {str(e)}")

# 하단 정보
st.divider()
st.caption("ML Systems Design 클래스 - Session 7")
st.caption("💡 팁: API 서버가 실행 중이어야 예측이 가능합니다.")